package demo;


import java.util.Random;
import java.awt.EventQueue; 
import com.sun.jna.Native;  
import com.sun.jna.win32.StdCallLibrary;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import javax.media.jai.JAI;
import com.sun.media.jai.codec.ImageCodec;  
import com.sun.media.jai.codec.ImageEncoder;
import com.sun.media.jai.codec.JPEGEncodeParam;
import javax.media.jai.RenderedOp;

public class Reader {
	public static short returnActualLength(byte[] data) {
        short i = 0;
        for (; i < data.length; i++) {
            if (data[i] == '\0')
                break;
        }
        return i;
    }
	public static String gbk_bytes_to_string(byte[] data) {
	    int i;
	    String s = "";

	    for (i = 0; i < data.length; ++i) {
	      if (data[i] == 0) {
	        break;
	      }
	    }

	    byte[] temp = new byte[i];
	    System.arraycopy(data, 0, temp, 0, temp.length);

	    try {
	      s = new String(temp, "GBK");
	    } catch (UnsupportedEncodingException e) {
	      e.printStackTrace();
	    }

	    return s;
	  }

	  public static byte[] string_to_gbk_bytes(String data) {
	    int i = 0;
	    byte[] s = null;

	    try {
	      s = data.getBytes("GBK");
	      i = s.length;
	    } catch (UnsupportedEncodingException e) {
	      e.printStackTrace();
	    }

	    byte[] temp = new byte[i + 1];
	    System.arraycopy(s, 0, temp, 0, i);
	    temp[i] = 0;

	    return temp;
	  }

	  public static void print_bytes(byte[] b, int length) {
	    for (int i = 0; i < length; ++i) {
	      String hex = Integer.toHexString(b[i] & 0xFF);
	      if (hex.length() == 1) {
	        hex = '0' + hex;
	      }
	      System.out.print(hex.toUpperCase());
	    }
	  }

	  public interface Dcrf32 extends StdCallLibrary {
	    void LibMain(int flag, byte[] version);

	    int dc_init(short port, int baud);

	    short dc_exit(int handle);
	    
	    short dc_beep(int handle, short _Msec);
	    
	    short dc_reset(int handle, short _Msec);
	    
	    short dc_config_card(int handle, char cardtype);
	    
	    short dc_card_n(int handle, byte _Mode,int[] SnrLen,byte[] _snr);
	    
	    short dc_authentication_passaddr(int handle, byte _Mode,byte _Addr,byte[] passbuff);
	    
	    short dc_write(int handle, byte _Adr,byte[] _Data);
	    
	    short dc_read(int handle, byte _Adr,byte[] _Data);
	    
	    short dc_initval(int handle, byte _Adr,int _Value);
	    
	    short dc_readval(int handle, byte _Adr,int[] _Value);
	    
	    short dc_increment(int handle, byte _Adr,int _Value);

	    short dc_decrement(int handle, byte _Adr,int _Value);

	    short dc_restore(int handle, byte _Adr);
	    
	    short dc_transfer(int handle, byte _Adr);
	    
	    short dc_pro_resetInt(int handle, byte[] rlen,byte[] receive_data);
	    
	    short dc_pro_commandlinkInt(int handle, int slen,byte[] sendbuffer,int[] rlen,byte[] databuffer,byte timeout);
	    
	    short hex_a(byte[] hex,byte[] a,short length);
	    
	    short a_hex(byte[] a,byte[] hex,short len);
	   
	    short dc_card_b(int handle,byte[] rbuf);
	    
	    short dc_MFPL0_writeperso(int handle,int BNr,byte[] dataperso);
	    
	    short dc_auth_ulc(int handle,byte[] dataperso);
	    
	    short dc_verifypin_4442(int handle,byte[] passwd);
	    
	    short dc_write_4442(int handle,int offset, int length,byte[] data_buffer);
	    
	    short dc_read_4442(int handle, int offset, int length, byte[] data_buffer);
	  
	    short dc_verifypin_4428(int handle,byte[] passwd);
	    
	    short dc_write_4428(int handle,int offset, int length,byte[] data_buffer);
	    
	    short dc_read_4428(int handle, int offset, int length, byte[] data_buffer);
	    
	    short dc_setcpu(int handle, byte _Byte);
	    
	    short dc_write_24c(int handle, int offset, int length, byte[] snd_buffer);
	    
	    short dc_read_24c(int handle, int offset, int length, byte[] receive_buffer);
	    
	    short dc_cpureset(int handle, byte[] rlen, byte[] databuffer);
	    
	    short dc_cpuapduInt(int handle, int slen, byte[] sendbuffer,int[] rlen, byte[] databuffer);
	    
	    short dc_getver(int handle, byte[] version);

	    short dc_startreadmag(int handle);

	    short dc_stopreadmag(int handle);
	    
	    short dc_readmag(int handle, byte[] t1_data, int[] t1_len, byte[] t2_data, int[] t2_len, byte[] t3_data, int[] t3_len);

	    short dc_card_exist(int handle, byte[] flag);

	    short dc_GetBankAccountNumber(int handle, int type, byte[] flag);

	    short dc_SamAReadCardInfo(int handle, int type, int[] text_len, byte[] text, int[] photo_len,
	        byte[] photo, int[] fingerprint_len, byte[] fingerprint, int[] extra_len, byte[] extra);

	    short dc_ParseTextInfo(int handle, int charset, int info_len, byte[] info, byte[] name,
	        byte[] sex, byte[] nation, byte[] birth_day, byte[] address, byte[] id_number,
	        byte[] department, byte[] expire_start_day, byte[] expire_end_day, byte[] reserved);

	    short dc_ParseTextInfoForForeigner(int handle, int charset, int info_len, byte[] info,
	        byte[] english_name, byte[] sex, byte[] id_number, byte[] citizenship, byte[] chinese_name,
	        byte[] expire_start_day, byte[] expire_end_day, byte[] birth_day, byte[] version_number,
	        byte[] department_code, byte[] type_sign, byte[] reserved);

	    short dc_ParsePhotoInfo(int handle, int type, int info_len, byte[] info, int[] photo_len,
	        byte[] photo);
	  }

	  short dc_Scan2DBarcodeStart(int handle, byte mode);
      short dc_Scan2DBarcodeGetData(int handle, int[] rlen, byte[] rdata);
      short dc_Scan2DBarcodeExit(int handle);
	  Dcrf32 dll_instance;

	  public void iInit(String path) {
	    dll_instance = (Dcrf32) Native.loadLibrary(path, Dcrf32.class);
	  }
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reader window = new Reader();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Reader() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 992, 595);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		JComboBox<Object> comboBox = new JComboBox<Object>();
		comboBox.setBounds(50, 31, 143, 21);
		comboBox.setModel(new DefaultComboBoxModel<Object>(new String[] {"usb","PCSC", "com1", "com2"}));
		comboBox.setSelectedIndex(0);
		frame.getContentPane().add(comboBox);
		
		JComboBox<Object> comboBox_1 = new JComboBox<Object>();
		comboBox_1.setBounds(340, 31, 143, 21);
		comboBox_1.setModel(new DefaultComboBoxModel<Object>(new String[] {"115200", "9600"}));
		comboBox_1.setSelectedIndex(0);
		frame.getContentPane().add(comboBox_1);
		
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(1, 1, 200, 300);
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(true);
		frame.getContentPane().add(textArea);
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(498, 12, 470, 530);
		frame.getContentPane().add(scrollPane);
		//jScrollPaneInfo = new JScrollPane(jTextAreaInfo);
        //getContentPane().add(jScrollPaneInfo);
        //jScrollPaneInfo.setBounds(347, 0, 290, 403);
		
		
		
		JButton btnNewButton = new JButton("M1WriteRead");
		btnNewButton.setBounds(10, 64, 122, 38);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Reader obj = new Reader();
			    short port = 100;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��Ƶ��λ
			    obj.dll_instance.dc_reset(icdev, (short)1);
				//���ÿ���
				st = obj.dll_instance.dc_config_card(icdev, 'A');
				//Ѱ�������ؿ����к�
				st = obj.dll_instance.dc_card_n(icdev, (byte)0, SnrLen, _Snr);
				if (st != 0)
				{
					textArea.append("dc_card_n Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_card_n Ok!\r\n");
					for (int i = 0; i < 4; i++)
					{
						_Snr[i] = _Snr[3 - i];
					}
					obj.dll_instance.hex_a(_Snr, szSnr, (short)4);
					textArea.append(gbk_bytes_to_string(szSnr));
					textArea.append("\r\n");
				}
				//��֤������
				byte[] password = new byte[7];
				java.util.Arrays.fill(password, (byte)0);
				password[0] = (byte)0xFF;
				password[1] = (byte)0xFF;
				password[2] = (byte)0xFF;
				password[3] = (byte)0xFF;
				password[4] = (byte)0xFF;
				password[5] = (byte)0xFF;
				st = obj.dll_instance.dc_authentication_passaddr(icdev,(byte)0, (byte)7, password);
				if (st != 0)
				{
					textArea.append("dc_authentication_passaddr Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_authentication_passaddr OK!\r\n");
				//д����
				byte[] writedata = new byte[17];
				java.util.Arrays.fill(writedata, (byte)0);
				writedata[0] = 0x30;
				writedata[1] = 0x31;
				writedata[2] = 0x32;
				writedata[3] = 0x33;
				writedata[4] = 0x34;
				writedata[5] = 0x35;
				writedata[6] = 0x36;
				writedata[7] = 0x37;
				writedata[8] = 0x38;
				writedata[9] = 0x39;
				writedata[10] = 0x30;
				writedata[11] = 0x31;
				writedata[12] = 0x32;
				writedata[13] = 0x33;
				writedata[14] = 0x34;
				writedata[15] = 0x35;
				st = obj.dll_instance.dc_write(icdev, (byte)4, writedata);
				if (st != 0)
				{
					textArea.append("dc_write Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_write OK!\r\n");
				byte[] rdata = new byte[100];
				byte[] rdatahex = new byte[100];
				java.util.Arrays.fill(rdata, (byte)0);
				java.util.Arrays.fill(rdatahex, (byte)0);
				//������
				st = obj.dll_instance.dc_read(icdev, (byte)4, rdata);
				if (st != 0)
				{
					textArea.append("dc_read Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					obj.dll_instance.hex_a(rdata, rdatahex, (short)16);
					textArea.append(gbk_bytes_to_string(rdatahex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("M1Value");
		btnNewButton_1.setBounds(135, 64, 122, 38);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��Ƶ��λ
			    obj.dll_instance.dc_reset(icdev, (short)1);
				//���ÿ���
				st = obj.dll_instance.dc_config_card(icdev, 'A');
				//Ѱ�������ؿ����к�
				st = obj.dll_instance.dc_card_n(icdev, (byte)0, SnrLen, _Snr);
				if (st != 0)
				{
					textArea.append("dc_card_n Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_card_n Ok!\r\n");
					for (int i = 0; i < 4; i++)
					{
						_Snr[i] = _Snr[3 - i];
					}
					obj.dll_instance.hex_a(_Snr, szSnr, (short)4);
					textArea.append(gbk_bytes_to_string(szSnr));
					textArea.append("\r\n");
				}
				//��֤������
				byte[] password = new byte[7];
				java.util.Arrays.fill(password, (byte)0);
				password[0] = (byte)0xFF;
				password[1] = (byte)0xFF;
				password[2] = (byte)0xFF;
				password[3] = (byte)0xFF;
				password[4] = (byte)0xFF;
				password[5] = (byte)0xFF;
				st = obj.dll_instance.dc_authentication_passaddr(icdev,(byte)0, (byte)7, password);
				if (st != 0)
				{
					textArea.append("dc_authentication_passaddr Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_authentication_passaddr OK!\r\n");
				//д����
				st = obj.dll_instance.dc_initval(icdev, (byte)5, 0);
				if (st != 0)
				{
					textArea.append("dc_initval Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_initval OK!\r\n");
				byte[] rdata = new byte[100];
				byte[] rdatahex = new byte[100];
				java.util.Arrays.fill(rdata, (byte)0);
				java.util.Arrays.fill(rdatahex, (byte)0);
				//������
				int[] uivalue = new int[1];
				uivalue[0] = 0;
				String s;
				st = obj.dll_instance.dc_readval(icdev, (byte)5, uivalue);
				if (st != 0)
				{
					textArea.append("dc_read Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					s=String.valueOf(uivalue[0]);
					textArea.append(s);
					textArea.append("\r\n");
				}
				
				st = obj.dll_instance.dc_increment(icdev, (byte)5, 1000);
				if (st != 0)
				{
					//MessageBoxA(0, "dc_increment Error!", "", MB_OK);
					textArea.append("dc_increment Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					//MessageBoxA(0, "dc_increment OK!", "", MB_OK);
					textArea.append("dc_increment OK!\r\n");
				//����ֵ
				st = obj.dll_instance.dc_readval(icdev, (byte)5, uivalue);
				if (st != 0)
				{
					textArea.append("dc_read Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					s=String.valueOf(uivalue[0]);
					textArea.append(s);
					textArea.append("\r\n");
				}
				//���ֵ
				st = obj.dll_instance.dc_decrement(icdev, (byte)5, 100);
				if (st != 0)
				{
				//MessageBoxA(0, "dc_decrement Error!", "", MB_OK);
					textArea.append("dc_decrement Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					//MessageBoxA(0, "dc_decrement OK!", "", MB_OK);
					textArea.append("dc_decrement OK!\r\n");
				//����ֵ
				st = obj.dll_instance.dc_readval(icdev, (byte)5, uivalue);
				if (st != 0)
				{
					textArea.append("dc_read Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					s=String.valueOf(uivalue[0]);
					textArea.append(s);
					textArea.append("\r\n");
				}
				//��ֵ����
				st = obj.dll_instance.dc_restore(icdev, (byte)5);
				if (st != 0)
				{
					//MessageBoxA(0, "dc_restore Error!!", "", MB_OK);
					textArea.append("dc_restore Error!!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					//MessageBoxA(0, "dc_restore OK!", "", MB_OK);
					textArea.append("dc_restore OK!\r\n");
				st = obj.dll_instance.dc_transfer(icdev, (byte)6);
				if (st != 0)
				{
					//MessageBoxA(0, "dc_transfer Error!", "", MB_OK);
					textArea.append("dc_transfer Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					//MessageBoxA(0, "dc_transfer OK!", "", MB_OK);
					textArea.append("dc_transfer OK!\r\n");
				//����ֵ
				st = obj.dll_instance.dc_readval(icdev, (byte)6, uivalue);
				if (st != 0)
				{
					textArea.append("dc_read Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					s=String.valueOf(uivalue[0]);
					textArea.append(s);
					textArea.append("\r\n");
				}
				
				
				
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("CpuTypeA");
		btnNewButton_2.setBounds(258, 64, 124, 38);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��Ƶ��λ
			    obj.dll_instance.dc_reset(icdev, (short)1);
				//���ÿ���
				st = obj.dll_instance.dc_config_card(icdev, 'A');
				//Ѱ�������ؿ����к�
				st = obj.dll_instance.dc_card_n(icdev, (byte)0, SnrLen, _Snr);
				if (st != 0)
				{
					textArea.append("dc_card_n Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_card_n Ok!\r\n");
					obj.dll_instance.hex_a(_Snr, szSnr, (short)SnrLen[0]);
					textArea.append(gbk_bytes_to_string(szSnr));
					textArea.append("\r\n");
				}
				byte[] databuffer = new byte[100];
				java.util.Arrays.fill(databuffer, (byte)0);
				byte[] rcardlen = new byte[2];
				java.util.Arrays.fill(rcardlen, (byte)0);
				byte[] databufferhex = new byte[100];
				java.util.Arrays.fill(databufferhex, (byte)0);
				st = obj.dll_instance.dc_pro_resetInt(icdev, rcardlen, databuffer);
				if (st != 0)
				{
					textArea.append("dc_pro_resetInt Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_pro_resetInt Ok!\r\n");
					obj.dll_instance.hex_a(databuffer, databufferhex, (short)rcardlen[0]);
					textArea.append(gbk_bytes_to_string(databufferhex));
					textArea.append("\r\n");
				}
				byte[] sendbuffer = new byte[100];
				java.util.Arrays.fill(sendbuffer, (byte)0);
				java.util.Arrays.fill(databuffer, (byte)0);
				sendbuffer[0] = (byte)0x00;
				sendbuffer[1] = (byte)0x84;
				sendbuffer[2] = (byte)0x00;
				sendbuffer[3] = (byte)0x00;
				sendbuffer[4] = (byte)0x08;
				int[] rlen = new int[2];
				java.util.Arrays.fill(rlen, 0);
				st = obj.dll_instance.dc_pro_commandlinkInt(icdev, 5, sendbuffer, rlen, databuffer, (byte)10);
				if (st != 0)
				{
					textArea.append("dc_pro_commandlinkInt Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_pro_commandlinkInt Ok!\r\n");
					obj.dll_instance.hex_a(databuffer, databufferhex, (byte)rlen[0]);
					textArea.append(gbk_bytes_to_string(databufferhex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("CpuTypeB");
		btnNewButton_3.setBounds(383, 64, 113, 38);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��Ƶ��λ
			    obj.dll_instance.dc_reset(icdev, (short)1);
				//���ÿ���
				st = obj.dll_instance.dc_config_card(icdev, 'B');
				//Ѱ�������ؿ����к�
				st = obj.dll_instance.dc_card_b(icdev, _Snr);
				if (st != 0)
				{
					textArea.append("dc_card_b Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_card_b Ok!\r\n");
					obj.dll_instance.hex_a(_Snr, szSnr, returnActualLength(_Snr));
					textArea.append(gbk_bytes_to_string(szSnr));
					textArea.append("\r\n");
				}
				byte[] databuffer = new byte[100];
				java.util.Arrays.fill(databuffer, (byte)0);
				byte[] databufferhex = new byte[100];
				java.util.Arrays.fill(databufferhex, (byte)0);
				byte[] sendbuffer = new byte[100];
				java.util.Arrays.fill(sendbuffer, (byte)0);
				java.util.Arrays.fill(databuffer, (byte)0);
				sendbuffer[0] = (byte)0x00;
				sendbuffer[1] = (byte)0x84;
				sendbuffer[2] = (byte)0x00;
				sendbuffer[3] = (byte)0x00;
				sendbuffer[4] = (byte)0x08;
				int[] rlen = new int[2];
				java.util.Arrays.fill(rlen, 0);
				st = obj.dll_instance.dc_pro_commandlinkInt(icdev, 5, sendbuffer, rlen, databuffer, (byte)10);
				if (st != 0)
				{
					textArea.append("dc_pro_commandlinkInt Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_pro_commandlinkInt Ok!\r\n");
					obj.dll_instance.hex_a(databuffer, databufferhex, (byte)rlen[0]);
					textArea.append(gbk_bytes_to_string(databufferhex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("MiFareDesFire");
		btnNewButton_4.setBounds(10, 112, 122, 38);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��Ƶ��λ
			    obj.dll_instance.dc_reset(icdev, (short)1);
				//Ѱ�������ؿ����к�
				st = obj.dll_instance.dc_card_n(icdev, (byte)0, SnrLen, _Snr);
				if (st != 0)
				{
					textArea.append("dc_card_n Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_card_n Ok!\r\n");
					obj.dll_instance.hex_a(_Snr, szSnr, (short)SnrLen[0]);
					textArea.append(gbk_bytes_to_string(szSnr));
					textArea.append("\r\n");
				}
				byte[] databuffer = new byte[100];
				java.util.Arrays.fill(databuffer, (byte)0);
				byte[] rcardlen = new byte[2];
				java.util.Arrays.fill(rcardlen, (byte)0);
				byte[] databufferhex = new byte[100];
				java.util.Arrays.fill(databufferhex, (byte)0);
				st = obj.dll_instance.dc_pro_resetInt(icdev, rcardlen, databuffer);
				if (st != 0)
				{
					textArea.append("dc_pro_resetInt Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_pro_resetInt Ok!\r\n");
					obj.dll_instance.hex_a(databuffer, databufferhex, (short)rcardlen[0]);
					textArea.append(gbk_bytes_to_string(databufferhex));
					textArea.append("\r\n");
				}
				byte[] sendbuffer = new byte[100];
				java.util.Arrays.fill(sendbuffer, (byte)0);
				java.util.Arrays.fill(databuffer, (byte)0);
				sendbuffer[0] = (byte)0x00;
				sendbuffer[1] = (byte)0x84;
				sendbuffer[2] = (byte)0x00;
				sendbuffer[3] = (byte)0x00;
				sendbuffer[4] = (byte)0x08;
				int[] rlen = new int[2];
				java.util.Arrays.fill(rlen, 0);
				st = obj.dll_instance.dc_pro_commandlinkInt(icdev, 5, sendbuffer, rlen, databuffer, (byte)10);
				if (st != 0)
				{
					textArea.append("dc_pro_commandlinkInt Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_pro_commandlinkInt Ok!\r\n");
					obj.dll_instance.hex_a(databuffer, databufferhex, (byte)rlen[0]);
					textArea.append(gbk_bytes_to_string(databufferhex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("MiFarePlus");
		btnNewButton_5.setBounds(135, 112, 122, 38);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��Ƶ��λ
			    obj.dll_instance.dc_reset(icdev, (short)1);
				//Ѱ�������ؿ����к�
				st = obj.dll_instance.dc_card_n(icdev, (byte)0, SnrLen, _Snr);
				if (st != 0)
				{
					textArea.append("dc_card_n Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_card_n Ok!\r\n");
					obj.dll_instance.hex_a(_Snr, szSnr, (short)SnrLen[0]);
					textArea.append(gbk_bytes_to_string(szSnr));
					textArea.append("\r\n");
				}
				byte[] databuffer = new byte[100];
				java.util.Arrays.fill(databuffer, (byte)0);
				byte[] rcardlen = new byte[2];
				java.util.Arrays.fill(rcardlen, (byte)0);
				byte[] databufferhex = new byte[100];
				java.util.Arrays.fill(databufferhex, (byte)0);
				st = obj.dll_instance.dc_pro_resetInt(icdev, rcardlen, databuffer);
				if (st != 0)
				{
					textArea.append("dc_pro_resetInt Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_pro_resetInt Ok!\r\n");
					obj.dll_instance.hex_a(databuffer, databufferhex, (short)rcardlen[0]);
					textArea.append(gbk_bytes_to_string(databufferhex));
					textArea.append("\r\n");
				}
				byte[] password = new byte[7];
				java.util.Arrays.fill(password, (byte)0);
				password[0] = (byte)0xFF;
				password[1] = (byte)0xFF;
				password[2] = (byte)0xFF;
				password[3] = (byte)0xFF;
				password[4] = (byte)0xFF;
				password[5] = (byte)0xFF;
				st = obj.dll_instance.dc_MFPL0_writeperso(icdev, 0x9000, password);//////////////////
				if (st != 0)
				{
					textArea.append("dc_MFPL0_writeperso_hex ERRO!\r\n");
					return;
				}
				textArea.append("dc_MFPL0_writeperso_hex Ok!\r\n");
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("UltraLight");
		btnNewButton_6.setBounds(258, 112, 124, 38);
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��Ƶ��λ
			    obj.dll_instance.dc_reset(icdev, (short)1);
				//���ÿ���
				st = obj.dll_instance.dc_config_card(icdev, 'A');
				//Ѱ�������ؿ����к�
				st = obj.dll_instance.dc_card_n(icdev, (byte)0, SnrLen, _Snr);
				if (st != 0)
				{
					textArea.append("dc_card_n Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_card_n Ok!\r\n");
					obj.dll_instance.hex_a(_Snr, szSnr, (short)SnrLen[0]);
					textArea.append(gbk_bytes_to_string(szSnr));
					textArea.append("\r\n");
				}
				//��֤������
				//д����
				byte[] writedata = new byte[17];
				java.util.Arrays.fill(writedata, (byte)0);
				writedata[0] = 0x30;
				writedata[1] = 0x31;
				writedata[2] = 0x32;
				writedata[3] = 0x33;
				writedata[4] = 0x34;
				writedata[5] = 0x35;
				writedata[6] = 0x36;
				writedata[7] = 0x37;
				writedata[8] = 0x38;
				writedata[9] = 0x39;
				writedata[10] = 0x30;
				writedata[11] = 0x31;
				writedata[12] = 0x32;
				writedata[13] = 0x33;
				writedata[14] = 0x34;
				writedata[15] = 0x35;
				st = obj.dll_instance.dc_write(icdev, (byte)4, writedata);
				if (st != 0)
				{
					textArea.append("dc_write Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_write OK!\r\n");
				byte[] rdata = new byte[100];
				byte[] rdatahex = new byte[100];
				java.util.Arrays.fill(rdata, (byte)0);
				java.util.Arrays.fill(rdatahex, (byte)0);
				//������
				st = obj.dll_instance.dc_read(icdev, (byte)4, rdata);
				if (st != 0)
				{
					textArea.append("dc_read Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					obj.dll_instance.hex_a(rdata, rdatahex, (short)16);
					textArea.append(gbk_bytes_to_string(rdatahex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("UltralightC");
		btnNewButton_7.setBounds(383, 112, 113, 38);
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��Ƶ��λ
			    obj.dll_instance.dc_reset(icdev, (short)1);
				//���ÿ���
				st = obj.dll_instance.dc_config_card(icdev, 'A');
				//Ѱ�������ؿ����к�
				st = obj.dll_instance.dc_card_n(icdev, (byte)0, SnrLen, _Snr);
				if (st != 0)
				{
					textArea.append("dc_card_n Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_card_n Ok!\r\n");
					obj.dll_instance.hex_a(_Snr, szSnr, (short)SnrLen[0]);
					textArea.append(gbk_bytes_to_string(szSnr));
					textArea.append("\r\n");
				}
				//��֤������
				byte[] password = new byte[7];
				java.util.Arrays.fill(password, (byte)0);
				password[0] = (byte)0xFF;
				password[1] = (byte)0xFF;
				password[2] = (byte)0xFF;
				password[3] = (byte)0xFF;
				password[4] = (byte)0xFF;
				password[5] = (byte)0xFF;
				st = obj.dll_instance.dc_auth_ulc(icdev,password);
				if (st != 0)
				{
					textArea.append("dc_auth_ulc Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_auth_ulc OK!\r\n");
				//д����
				byte[] writedata = new byte[17];
				java.util.Arrays.fill(writedata, (byte)0);
				writedata[0] = 0x30;
				writedata[1] = 0x31;
				writedata[2] = 0x32;
				writedata[3] = 0x33;
				writedata[4] = 0x34;
				writedata[5] = 0x35;
				writedata[6] = 0x36;
				writedata[7] = 0x37;
				writedata[8] = 0x38;
				writedata[9] = 0x39;
				writedata[10] = 0x30;
				writedata[11] = 0x31;
				writedata[12] = 0x32;
				writedata[13] = 0x33;
				writedata[14] = 0x34;
				writedata[15] = 0x35;
				st = obj.dll_instance.dc_write(icdev, (byte)4, writedata);
				if (st != 0)
				{
					textArea.append("dc_write Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_write OK!\r\n");
				byte[] rdata = new byte[100];
				byte[] rdatahex = new byte[100];
				java.util.Arrays.fill(rdata, (byte)0);
				java.util.Arrays.fill(rdatahex, (byte)0);
				//������
				st = obj.dll_instance.dc_read(icdev, (byte)4, rdata);
				if (st != 0)
				{
					textArea.append("dc_read Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					obj.dll_instance.hex_a(rdata, rdatahex, (short)16);
					textArea.append(gbk_bytes_to_string(rdatahex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("4442");
		btnNewButton_8.setBounds(10, 156, 122, 38);
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��֤������
				byte[] password = new byte[4];
				java.util.Arrays.fill(password, (byte)0);
				password[0] = (byte)0xFF;
				password[1] = (byte)0xFF;
				password[2] = (byte)0xFF;
				st = obj.dll_instance.dc_verifypin_4442(icdev,password);
				if (st != 0)
				{
					textArea.append("dc_verifypin_4442 Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_verifypin_4442 OK!\r\n");
				//д����
				byte[] writedata = new byte[100];
				java.util.Arrays.fill(writedata, (byte)0);
				for(int i = 0;i < 50;i++)
				{
					Random rnd = new Random();
					writedata[i] = (byte)rnd.nextInt(256);
				}
				
				st = obj.dll_instance.dc_write_4442(icdev, 32,50,writedata);
				if (st != 0)
				{
					textArea.append("dc_write_4442 Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_write_4442 OK!\r\n");
				byte[] rdata = new byte[100];
				byte[] rdatahex = new byte[100];
				java.util.Arrays.fill(rdata, (byte)0);
				java.util.Arrays.fill(rdatahex, (byte)0);
				//������
				st = obj.dll_instance.dc_read_4442(icdev, 32,50, rdata);
				if (st != 0)
				{
					textArea.append("dc_read_4442 Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					obj.dll_instance.hex_a(rdata, rdatahex, (short)50);
					textArea.append(gbk_bytes_to_string(rdatahex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("4428");
		btnNewButton_9.setBounds(135, 156, 122, 38);
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//��֤������
				byte[] password = new byte[3];
				java.util.Arrays.fill(password, (byte)0);
				password[0] = (byte)0xFF;
				password[1] = (byte)0xFF;
				st = obj.dll_instance.dc_verifypin_4428(icdev,password);
				if (st != 0)
				{
					textArea.append("dc_verifypin_4428 Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_verifypin_4428 OK!\r\n");
				//д����
				byte[] writedata = new byte[51];
				java.util.Arrays.fill(writedata, (byte)0);
				for(int i = 0;i < 50;i++)
				{
					Random rnd = new Random();
					writedata[i] = (byte)rnd.nextInt(256);
				}
				
				st = obj.dll_instance.dc_write_4428(icdev, 32,50,writedata);
				if (st != 0)
				{
					textArea.append("dc_write_4428 Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_write_4428 OK!\r\n");
				byte[] rdata = new byte[100];
				byte[] rdatahex = new byte[100];
				java.util.Arrays.fill(rdata, (byte)0);
				java.util.Arrays.fill(rdatahex, (byte)0);
				//������
				st = obj.dll_instance.dc_read_4428(icdev, 32,50, rdata);
				if (st != 0)
				{
					textArea.append("dc_read_4428 Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					obj.dll_instance.hex_a(rdata, rdatahex, (short)50);
					textArea.append(gbk_bytes_to_string(rdatahex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("24CXX");
		btnNewButton_10.setBounds(258, 156, 124, 38);
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    int[] SnrLen = new int[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, 0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				byte[] writedata = new byte[51];
				java.util.Arrays.fill(writedata, (byte)0);
				for(int i = 0;i < 50;i++)
				{
					Random rnd = new Random();
					writedata[i] = (byte)rnd.nextInt(256);
				}
				
				st = obj.dll_instance.dc_write_24c(icdev, 32,50,writedata);
				if (st != 0)
				{
					textArea.append("dc_write_24c Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
					textArea.append("dc_write_24c OK!\r\n");
				byte[] rdata = new byte[100];
				byte[] rdatahex = new byte[100];
				java.util.Arrays.fill(rdata, (byte)0);
				java.util.Arrays.fill(rdatahex, (byte)0);
				//������
				st = obj.dll_instance.dc_read_24c(icdev, 32,50, rdata);
				if (st != 0)
				{
					textArea.append("dc_read_24c Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_read_24c Ok!\r\n");
					obj.dll_instance.hex_a(rdata, rdatahex, (short)50);
					textArea.append(gbk_bytes_to_string(rdatahex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("Cpu");
		btnNewButton_11.setBounds(383, 156, 113, 38);
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    byte[] SnrLen = new byte[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, (byte)0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			    	//textArea.setCaretPosition(textArea.getDocument().getLength()); 
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    //textArea.setCaretPosition(textArea.getDocument().getLength()); 
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
				//���ÿ���
				st = obj.dll_instance.dc_setcpu(icdev, (byte)13);
				//Ѱ�������ؿ����к�
				st = obj.dll_instance.dc_cpureset(icdev,SnrLen, _Snr);
				if (st != 0)
				{
					textArea.append("dc_cpureset Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_cpureset Ok!\r\n");
					obj.dll_instance.hex_a(_Snr, szSnr, SnrLen[0]);
					textArea.append(gbk_bytes_to_string(szSnr));
					textArea.append("\r\n");
				}
				byte[] databuffer = new byte[100];
				java.util.Arrays.fill(databuffer, (byte)0);
				byte[] rcardlen = new byte[2];
				java.util.Arrays.fill(rcardlen, (byte)0);
				byte[] databufferhex = new byte[100];
				java.util.Arrays.fill(databufferhex, (byte)0);
				byte[] sendbuffer = new byte[100];
				java.util.Arrays.fill(sendbuffer, (byte)0);
				java.util.Arrays.fill(databuffer, (byte)0);
				sendbuffer[0] = (byte)0x00;
				sendbuffer[1] = (byte)0x84;
				sendbuffer[2] = (byte)0x00;
				sendbuffer[3] = (byte)0x00;
				sendbuffer[4] = (byte)0x08;
				int[] rlen = new int[2];
				java.util.Arrays.fill(rlen, 0);
				st = obj.dll_instance.dc_cpuapduInt(icdev, 5, sendbuffer, rlen, databuffer);
				if (st != 0)
				{
					textArea.append("dc_cpuapduInt Error!\r\n");
					if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
					return;
				}
				else
				{
					textArea.append("dc_cpuapduInt Ok!\r\n");
					obj.dll_instance.hex_a(databuffer, databufferhex, (byte)rlen[0]);
					textArea.append(gbk_bytes_to_string(databufferhex));
					textArea.append("\r\n");
				}
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_11);
		
		JLabel picture1 = new JLabel("��Ƭ",JLabel.CENTER);
		picture1.setBounds(300, 200, 150, 200);
		picture1.setBorder(BorderFactory.createLineBorder(Color.black));
		picture1.setVisible(true);
		frame.getContentPane().add(picture1);
		
		JButton btnNewButton_12 = new JButton("ID");
		btnNewButton_12.setBounds(10, 200, 124, 38);
		btnNewButton_12.addActionListener(new ActionListener() {
			//private OutputStream os2;

			public void actionPerformed(ActionEvent e) {
				Reader obj = new Reader();
			    short port = 100;
			    //int baud = 115200;
			    int st = -1;
			    int icdev = -1;
			    int[] text_len = new int[1];
			    byte[] text = new byte[256];
			    int[] photo_len = new int[1];
			    byte[] photo = new byte[1024];
			    int[] fingerprint_len = new int[1];
			    byte[] fingerprint = new byte[1024];
			    int[] extra_len = new int[1];
			    byte[] extra = new byte[70];
			    int type = 0;
			    byte[] _Snr = new byte[100];
			    byte[] szSnr = new byte[200];
			    byte[] SnrLen = new byte[10];
			    java.util.Arrays.fill(_Snr, (byte)0);
			    java.util.Arrays.fill(szSnr, (byte)0);
			    java.util.Arrays.fill(SnrLen, (byte)0);
			   
			    obj.iInit("dcrf32.dll");
			    
			    int baund = 0;
			    String itemtxt = comboBox.getSelectedItem().toString();
			    baund = Integer.parseInt(comboBox_1.getSelectedItem().toString());
			    if(itemtxt == "usb")
			    	port = 100;
				else if(itemtxt == "PCSC")
			    	port = 200;
			    else if(itemtxt == "com1")
			    	port = 0;
			    else if(itemtxt == "com2")
			    	port = 1;
			    st = obj.dll_instance.dc_init(port,baund);
			    if (st < 0) {
			    	textArea.append("dc_init error!\r\n");
			      return;
			    }
			    textArea.append("dc_init ok!\r\n");
			    icdev = st;
			    obj.dll_instance.dc_beep(icdev, (short)10);
			    st = obj.dll_instance.dc_SamAReadCardInfo(icdev, 3, text_len, text, photo_len, photo, fingerprint_len, fingerprint, extra_len, extra);
			      if (st < 0) {
			        textArea.append("dc_SamAReadCardInfo error!\r\n");
			        if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
			        return;
			      }
			      textArea.append("dc_SamAReadCardInfo ok!\r\n");

			      if ((text[0] >= 'A') && (text[0] <= 'Z') && (text[1] == 0)) {
			        type = 1;
			      }

			      if (type == 0) {
			        textArea.append("�����ͣ��й��˾�������֤\r\n");

			        byte[] name = new byte[64];
			        byte[] sex = new byte[8];
			        byte[] nation = new byte[12];
			        byte[] birth_day = new byte[36];
			        byte[] address = new byte[144];
			        byte[] id_number = new byte[76];
			        byte[] department = new byte[64];
			        byte[] expire_start_day = new byte[36];
			        byte[] expire_end_day = new byte[36];
			        byte[] reserved = new byte[76];

			        textArea.append("dc_ParseTextInfo ...\r\n ");
			        st = obj.dll_instance.dc_ParseTextInfo(icdev, 0, text_len[0], text, name, sex, nation, birth_day, address, id_number, department, expire_start_day, expire_end_day, reserved);
			        if (st < 0) {
			          textArea.append("dc_ParseTextInfo erro!\r\n");
			          if(icdev > 0)
					    {
					    	st = obj.dll_instance.dc_exit(icdev);
					    	if(st !=0 )
					    	{
						    	textArea.append("dc_exit error!\r\n");
						    	return;
						    }
					    	else
					    	{
					    		textArea.append("dc_exit ok!\r\n");
					    		icdev = -1;
					    	}
					    }
			          return;
			        }
			        textArea.append("dc_ParseTextInfo ok!\r\n");

			        textArea.append("������" + gbk_bytes_to_string(name));
			        textArea.append("\r\n");
			        textArea.append("�Ա�" + gbk_bytes_to_string(sex));
			        textArea.append("\r\n");
			        textArea.append("���壺" + gbk_bytes_to_string(nation));
			        textArea.append("\r\n");
			        textArea.append("�������ڣ�" + gbk_bytes_to_string(birth_day));
			        textArea.append("\r\n");
			        textArea.append("סַ��" + gbk_bytes_to_string(address));
			        textArea.append("\r\n");
			        textArea.append("�������ݺ��룺" + gbk_bytes_to_string(id_number));
			        textArea.append("\r\n");
			        textArea.append("ǩ�����أ�" + gbk_bytes_to_string(department));
			        textArea.append("\r\n");
			        textArea.append("֤��ǩ�����ڣ�" + gbk_bytes_to_string(expire_start_day));
			        textArea.append("\r\n");
			        textArea.append("֤����ֹ���ڣ�" + gbk_bytes_to_string(expire_end_day));
			        textArea.append("\r\n");
			      } else if (type == 1) {
			        textArea.append("�����ͣ���������þ���֤\r\n");

			        byte[] english_name = new byte[244];
			        byte[] sex = new byte[8];
			        byte[] id_number = new byte[64];
			        byte[] citizenship = new byte[16];
			        byte[] chinese_name = new byte[64];
			        byte[] expire_start_day = new byte[36];
			        byte[] expire_end_day = new byte[36];
			        byte[] birth_day = new byte[36];
			        byte[] version_number = new byte[12];
			        byte[] department_code = new byte[20];
			        byte[] type_sign = new byte[8];
			        byte[] reserved = new byte[16];

			        textArea.append("dc_ParseTextInfoForForeigner ... \r\n");
			        st = obj.dll_instance.dc_ParseTextInfoForForeigner(icdev, 0, text_len[0], text, english_name, sex, id_number, citizenship, chinese_name, expire_start_day, expire_end_day, birth_day, version_number, department_code, type_sign, reserved);
			        if (st < 0) {
			          textArea.append("dc_ParseTextInfoForForeigner error!\r\n");
			          if(icdev > 0)
					    {
					    	st = obj.dll_instance.dc_exit(icdev);
					    	if(st !=0 )
					    	{
						    	textArea.append("dc_exit error!\r\n");
						    	return;
						    }
					    	else
					    	{
					    		textArea.append("dc_exit ok!\r\n");
					    		icdev = -1;
					    	}
					    }
			          return;
			        }
			        textArea.append("dc_ParseTextInfoForForeigner ok!\r\n");

			        textArea.append("Ӣ��������" + gbk_bytes_to_string(english_name));
			        textArea.append("\r\n");
			        textArea.append("�Ա�" + gbk_bytes_to_string(sex));
			        textArea.append("\r\n");
			        textArea.append("���þ���֤���룺" + gbk_bytes_to_string(id_number));
			        textArea.append("\r\n");
			        textArea.append("���������ڵ������룺" + gbk_bytes_to_string(citizenship));
			        textArea.append("\r\n");
			        textArea.append("����������" + gbk_bytes_to_string(chinese_name));
			        textArea.append("\r\n");
			        textArea.append("֤��ǩ�����ڣ�" + gbk_bytes_to_string(expire_start_day));
			        textArea.append("\r\n");
			        textArea.append("֤����ֹ���ڣ�" + gbk_bytes_to_string(expire_end_day));
			        textArea.append("\r\n");
			        textArea.append("�������ڣ�" + gbk_bytes_to_string(birth_day));
			        textArea.append("\r\n");
			        textArea.append("֤���汾�ţ�" + gbk_bytes_to_string(version_number));
			        textArea.append("\r\n");
			        textArea.append("���������������ش��룺" + gbk_bytes_to_string(department_code));
			        textArea.append("\r\n");
			        textArea.append("֤�����ͱ�ʶ��" + gbk_bytes_to_string(type_sign));
			        textArea.append("\r\n");
			      }

			      textArea.append("dc_ParsePhotoInfo ... \r\n");
			      st = obj.dll_instance.dc_ParsePhotoInfo(icdev, 0, photo_len[0], photo, null, string_to_gbk_bytes("me.bmp"));
			      if (st < 0) {
			        textArea.append("dc_ParsePhotoInfo error!\r\n");
			        if(icdev > 0)
				    {
				    	st = obj.dll_instance.dc_exit(icdev);
				    	if(st !=0 )
				    	{
					    	textArea.append("dc_exit error!\r\n");
					    	return;
					    }
				    	else
				    	{
				    		textArea.append("dc_exit ok!\r\n");
				    		icdev = -1;
				    	}
				    }
			        return;
			      }
			      textArea.append("dc_ParsePhotoInfo ok!\r\n");
			        String input2 = "me.bmp";  
			        String output2 = "me.jpg";  
			        RenderedOp src2 = JAI.create("fileload", input2);  
			        OutputStream os2 = null;
			        try
			        {
			        	os2 = new FileOutputStream(output2);  
			        }
			        catch(IOException ex)
			        {
			        	
			        }
			        JPEGEncodeParam param2 = new JPEGEncodeParam();   
			        ImageEncoder enc2 = ImageCodec.createImageEncoder("JPEG", os2, param2);  
			        try
			        {
			        	enc2.encode(src2);  
			        }
			        catch(IOException ex)
			        {
			        	
			        }
			        try
			        {
			        	os2.close();  
			        }
			        catch(IOException ex)
			        {
			        	
			        }
			        ImageIcon image = new ImageIcon("me.jpg");
			        picture1.setText("");
				    
					picture1.setIcon(image);  //add a label contains the image which have to change to ImageIcon;			      
			    if(icdev > 0)
			    {
			    	st = obj.dll_instance.dc_exit(icdev);
			    	if(st !=0 )
			    	{
				    	textArea.append("dc_exit error!\r\n");
				    	return;
				    }
			    	else
			    	{
			    		textArea.append("dc_exit ok!\r\n");
			    		icdev = -1;
			    	}
			    }
			}
		});
		frame.getContentPane().add(btnNewButton_12);
		JLabel lblPort = new JLabel("port:");
		lblPort.setBounds(12, 32, 55, 18);
		frame.getContentPane().add(lblPort);
		JLabel lblBaund = new JLabel("baund:");
		lblBaund.setBounds(288, 32, 55, 18);
		frame.getContentPane().add(lblBaund);
	}
}
