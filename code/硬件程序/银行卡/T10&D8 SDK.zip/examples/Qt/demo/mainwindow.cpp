#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QLibrary>
#include <QDebug>
#include <QTextCodec>
#include <QString>
extern "C"    //由于是C版的dll文件，在C++中引入其头文件要加extern "C" {},注意
{
        #include "dcrf32.h"
}


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->comboBox->addItem("usb");
    ui->comboBox->addItem("com1");
    ui->comboBox->addItem("com2");
    ui->comboBox->setCurrentIndex(0);
    ui->comboBox_2->addItem("115200");
    ui->comboBox_2->addItem("9600");
    ui->comboBox_2->setCurrentIndex(0);
    ui->label_9->setAlignment(Qt::AlignCenter);
    ui->label_9->setStyleSheet("border:2px solid black;");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev=(HANDLE)-1;
    int st = -1;
    unsigned char _Snr[100] = "\0";
    unsigned char szSnr[100] = "\0";
    unsigned int SnrLen = 0;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    //if (str == "usb")
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    //射频复位
    dc_reset(icdev, 1);
    //设置卡型
    st = dc_config_card(icdev, 'A');
    //寻卡并返回卡序列�
    st = dc_card_n(icdev, 0, &SnrLen, _Snr);
    if (st != 0)
    {
        ui->textEdit->append("dc_card_n Error!");
        return;
    }
    else
    {
        ui->textEdit->append("dc_card_n Ok!");
        for (int i = 0; i < 4; i++)
        {
            _Snr[i] = _Snr[3 - i];
        }
        memset(szSnr, 0x00, sizeof(szSnr));
        hex_a(_Snr, szSnr, 4);
        std::string str1 = (char*)szSnr;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
        //ui->textEdit->append(szSnr);
    }
    //验证卡密�
    st = dc_authentication_passaddr(icdev, 0, 7, (unsigned char *)"\xFF\xFF\xFF\xFF\xFF\xFF");
    if (st != 0)
    {
        ui->textEdit->append("dc_authentication_passaddr Error!");
        return;
    }
    else
        ui->textEdit->append("dc_authentication_passaddr OK!");
    //写扇�
    st = dc_write(icdev, 4, (unsigned char*)"\x31\x32\x33\x34\x35\x36\x37\x38\x39\x30\x31\x32\x33\x34\x35\x36");
    if (st != 0)
    {
        ui->textEdit->append("dc_write Error!");
        return;
    }
    else
        ui->textEdit->append("dc_write OK!");
    unsigned char rdata[100] = "\0";
    unsigned char rdatahex[100] = "\0";
    //读扇�
    st = dc_read(icdev, 4, rdata);
    if (st != 0)
    {
        ui->textEdit->append("dc_read Error!");
        return;
    }
    else
    {
        memset(rdatahex, 0x00, sizeof(rdatahex));
        hex_a(rdata, rdatahex, 16);
        std::string str1 = (char*)rdatahex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}

void MainWindow::on_pushButton_2_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    unsigned char _Snr[100] = "\0";
    unsigned char szSnr[100] = "\0";
    unsigned int SnrLen = 0;
    unsigned int uivalue = 0;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    //if (str == "usb")
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        //MessageBoxA(0, "Init Com Error!", "", MB_OK);
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        //MessageBoxA(0, "Init Com OK!", "", MB_OK);
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    //射频复位
    dc_reset(icdev, 1);
    //设置卡型
    st = dc_config_card(icdev, 'A');
    //寻卡并返回卡序列�
    st = dc_card_n(icdev, 0, &SnrLen, _Snr);
    if (st != 0)
    {
        //MessageBoxA(0, "dc_card_n Error!", "", MB_OK);
        ui->textEdit->append("dc_card_n Error!");
        return;
    }
    else
    {
        //MessageBoxA(0, "dc_card_n Ok!", "", MB_OK);
        ui->textEdit->append("dc_card_n Ok!");
        for (int i = 0; i < 4; i++)
        {
            _Snr[i] = _Snr[3 - i];
        }
        memset(szSnr, 0x00, sizeof(szSnr));
        hex_a(_Snr, szSnr, 4);
        std::string str1 = (char*)szSnr;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
        //MessageBoxA(0, (LPCSTR)szSnr, "", MB_OK);
        //ui->textEdit->append((LPCSTR)szSnr);
    }
    //验证卡密�
    st = dc_authentication_passaddr(icdev, 0, 7, (unsigned char *)"\xFF\xFF\xFF\xFF\xFF\xFF");
    if (st != 0)
    {
        //MessageBoxA(0, "dc_authentication_passaddr Error!", "", MB_OK);
        ui->textEdit->append("dc_authentication_passaddr Error!");
        return;
    }
    else
        //MessageBoxA(0, "dc_authentication_passaddr OK!", "", MB_OK);
        ui->textEdit->append("dc_authentication_passaddr OK!");
    //块值初始化�
    st = dc_initval(icdev, 5, 0);
    if (st != 0)
    {
        //MessageBoxA(0, "dc_initval Error!", "", MB_OK);
        ui->textEdit->append("dc_initval Error!");
        return;
    }
    else
        //MessageBoxA(0, "dc_initval OK!", "", MB_OK);
        ui->textEdit->append("dc_initval OK!");
    //读块�
    st = dc_readval(icdev, 5, &uivalue);
    if (st != 0)
    {
        //MessageBoxA(0, "dc_readval Erro!", "", MB_OK);
        ui->textEdit->append("dc_readval Erro!");
        return;
    }
    else
    {
        //_itoa_s(uivalue, cvalue, 10);
        str = QString::number(uivalue, 10);             // s == "63"
        //MessageBoxA(0, cvalue, "", MB_OK);
        ui->textEdit->append(str);
    }
    //块加�
    st = dc_increment(icdev, 5, 1000);
    if (st != 0)
    {
        //MessageBoxA(0, "dc_increment Error!", "", MB_OK);
        ui->textEdit->append("dc_increment Error!");
        return;
    }
    else
        //MessageBoxA(0, "dc_increment OK!", "", MB_OK);
        ui->textEdit->append("dc_increment OK!");
    //读块�
    st = dc_readval(icdev, 5, &uivalue);
    if (st != 0)
    {
        //MessageBoxA(0, "dc_readval Erro!", "", MB_OK);
        ui->textEdit->append("dc_readval Erro!");
        return;
    }
    else
    {
        //_itoa_s(uivalue, cvalue, 10);
        str = QString::number(uivalue,10);
        //MessageBoxA(0, cvalue, "", MB_OK);
        ui->textEdit->append(str);
    }
    //块减�
    st = dc_decrement(icdev, 5, 100);
    if (st != 0)
    {
    //MessageBoxA(0, "dc_decrement Error!", "", MB_OK);
        ui->textEdit->append("dc_decrement Error!");
        return;
    }
    else
        //MessageBoxA(0, "dc_decrement OK!", "", MB_OK);
        ui->textEdit->append("dc_decrement OK!");
    //读块�
    st = dc_readval(icdev, 5, &uivalue);
    if (st != 0)
    {
        //MessageBoxA(0, "dc_readval Erro!", "", MB_OK);
        ui->textEdit->append("dc_readval Erro!");
        return;
    }
    else
    {
        //_itoa_s(uivalue, cvalue, 10);
        str = QString::number(uivalue,10);
        //MessageBoxA(0, cvalue, "", MB_OK);
        ui->textEdit->append(str);
    }
    //块值传�
    st = dc_restore(icdev, 5);
    if (st != 0)
    {
        //MessageBoxA(0, "dc_restore Error!!", "", MB_OK);
        ui->textEdit->append("dc_restore Error!!");
        return;
    }
    else
        //MessageBoxA(0, "dc_restore OK!", "", MB_OK);
        ui->textEdit->append("dc_restore OK!");
    st = dc_transfer(icdev, 6);
    if (st != 0)
    {
        //MessageBoxA(0, "dc_transfer Error!", "", MB_OK);
        ui->textEdit->append("dc_transfer Error!");
        return;
    }
    else
        //MessageBoxA(0, "dc_transfer OK!", "", MB_OK);
        ui->textEdit->append("dc_transfer OK!");
    //读块�
    st = dc_readval(icdev, 6, &uivalue);
    if (st != 0)
    {
        //MessageBoxA(0, "dc_readval Erro!", "", MB_OK);
        ui->textEdit->append("dc_readval Erro!");
        return;
    }
    else
    {
        str = QString::number(uivalue,10);
        //MessageBoxA(0, cvalue, "", MB_OK);
        ui->textEdit->append(str);
    }
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            //MessageBoxA(0, "dc_exit Error!", "", MB_OK);
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            //MessageBoxA(0, "dc_exit OK!", "", MB_OK);
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
}

void MainWindow::on_pushButton_3_clicked()
{
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    unsigned char _Snr[100] = "\0";
    unsigned char szSnr[100] = "\0";
    unsigned int SnrLen = 0;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    //if (str == "usb")
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    //射频复位
    dc_reset(icdev, 1);
    st = dc_config_card(icdev, 'A');
    st = dc_card_n(icdev, 0, &SnrLen, _Snr);
    if (st != 0)
    {
        ui->textEdit->append("dc_card_n Error!");
        return;
    }
    else
    {
        ui->textEdit->append("dc_card_n Ok!");
        memset(szSnr, 0x00, sizeof(szSnr));
        hex_a(_Snr, szSnr, SnrLen);
        std::string str1 = (char*)szSnr;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    unsigned char rcardlen = 0;
    unsigned int rlen = 0;
    unsigned char databuffer[100] = "\0";
    unsigned char databufferhex[100] = "\0";
    st = dc_pro_resetInt(icdev, &rcardlen, databuffer);
    if (st != 0)
    {
        ui->textEdit->append("dc_pro_resetInt Error!");
        return;
    }
    else
    {
        ui->textEdit->append("dc_pro_resetInt Ok!");
        hex_a(databuffer, databufferhex, (short)rcardlen);
        std::string str1 = (char*)databufferhex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    st = dc_pro_commandlinkInt(icdev, 5, (unsigned char*)"\x00\x84\x00\x00\x08", &rlen, databuffer, 10);
    if (st != 0)
    {
        ui->textEdit->append("dc_pro_commandlinkInt Error!");
        return;
    }
    else
    {
        ui->textEdit->append("dc_pro_commandlinkInt Ok!");
        hex_a(databuffer, databufferhex, rlen);
        std::string str1 = (char*)databufferhex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}

void MainWindow::on_pushButton_4_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    unsigned char _Snr[100] = "\0";
    unsigned char szSnr[100] = "\0";
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    //if (str == "usb")
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    //射频复位
    dc_reset(icdev, 1);
    st = dc_config_card(icdev, 'B');
    st = dc_card_b(icdev, _Snr);
    if (st != 0)
    {
        ui->textEdit->append("dc_card_b Error!");
        return;
    }
    else
    {
        ui->textEdit->append("dc_card_b Ok!");
        hex_a(_Snr, szSnr, 11);
        std::string str1 = (char*)szSnr;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    unsigned int rlen = 0;
    unsigned char databuffer[100] = "\0";
    unsigned char databufferhex[100] = "\0";
    st = dc_pro_commandlinkInt(icdev, 5, (unsigned char*)"\x00\x84\x00\x00\x08", &rlen, databuffer, 10);
    if (st != 0)
    {
        ui->textEdit->append("dc_pro_commandlinkInt Error!");
        return;
    }
    else
    {
        ui->textEdit->append("dc_pro_commandlinkInt Ok!");
        hex_a(databuffer, databufferhex, rlen);
        std::string str1 = (char*)databufferhex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
}

void MainWindow::on_pushButton_5_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    unsigned char _Snr[100] = "\0";
    unsigned char szSnr[100] = "\0";
    unsigned int SnrLen = 0;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    //if (str == "usb")
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    //射频复位
    dc_reset(icdev, 1);
    st = dc_config_card(icdev, 'A');
    st = dc_card_n(icdev, 0, &SnrLen, _Snr);
    if (st != 0)
    {
        ui->textEdit->append("dc_card_n Error!");
        return;
    }
    else
    {
        ui->textEdit->append("dc_card_n Ok!");
        memset(szSnr, 0x00, sizeof(szSnr));
        hex_a(_Snr, szSnr, SnrLen);
        std::string str1 = (char*)szSnr;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    unsigned char rcardlen = 0;
    unsigned int rlen = 0;
    unsigned char databuffer[100] = "\0";
    unsigned char databufferhex[100] = "\0";
    st = dc_pro_resetInt(icdev, &rcardlen, databuffer);
    if (st != 0)
    {
        ui->textEdit->append("dc_pro_resetInt Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_pro_resetInt Ok!");
        hex_a(databuffer, databufferhex, (short)rcardlen);
        std::string str1 = (char*)databufferhex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    st = dc_pro_commandlinkInt(icdev, 5, (unsigned char*)"\x00\x84\x00\x00\x08", &rlen, databuffer, 10);
    if (st != 0)
    {
        ui->textEdit->append("dc_pro_commandlinkInt Error!");
        return;
    }
    else
    {
        ui->textEdit->append("dc_pro_commandlinkInt Ok!");
        hex_a(databuffer, databufferhex, rlen);
        std::string str1 = (char*)databufferhex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    safeExit:
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
}

void MainWindow::on_pushButton_7_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    unsigned char _Snr[100] = "\0";
    unsigned char szSnr[100] = "\0";
    unsigned int SnrLen = 0;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    //if (str == "usb")
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    unsigned char rLen = 0;
    unsigned char receive_data[256] = "\0";
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    //射频复位
    dc_reset(icdev, 1);
    st = dc_card_n(icdev, 0, &SnrLen, _Snr);
    if (st != 0)
    {
        ui->textEdit->append("dc_card_n Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_card_n Ok!");
        memset(szSnr, 0x00, sizeof(szSnr));
        hex_a(_Snr, szSnr, SnrLen);
        std::string str1 = (char*)szSnr;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }

    st = dc_pro_reset(icdev, &rLen, receive_data);
    if (st != 0)
    {
        ui->textEdit->append("dc_card_n Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_card_n Ok!");
        memset(szSnr, 0x00, sizeof(szSnr));
        hex_a(receive_data, szSnr, rLen);
        std::string str1 = (char*)szSnr;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }

    st = dc_MFPL0_writeperso(icdev, 0x9000, (unsigned char *)"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF");//////////////////
    if (st)
    {
        ui->textEdit->append("dc_MFPL0_writeperso_hex ERRO!");
        goto safeExit;
        return;
    }
    ui->textEdit->append("dc_MFPL0_writeperso_hex Ok!");
    safeExit:
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}

void MainWindow::on_pushButton_8_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    unsigned char _Snr[100] = "\0";
    unsigned char szSnr[100] = "\0";
    unsigned int SnrLen = 0;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    unsigned char rdata[100] = "\0";
    unsigned char rdatahex[100] = "\0";
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    //射频复位
    dc_reset(icdev, 1);
    st = dc_card_n(icdev, 0, &SnrLen, _Snr);
    if (st != 0)
    {
        ui->textEdit->append("dc_card_n Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_card_n Ok!");
        memset(szSnr, 0x00, sizeof(szSnr));
        hex_a(_Snr, szSnr, SnrLen);
        std::string str1 = (char*)szSnr;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    st = dc_write(icdev, 4, (unsigned char*)"\x31\x32\x33\x34\x35\x36\x37\x38\x39\x30\x31\x32\x33\x34\x35\x36");
    if (st != 0)
    {
        ui->textEdit->append("dc_write Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_write OK!");
    }

    //读扇�
    st = dc_read(icdev, 4, rdata);
    if (st != 0)
    {
        ui->textEdit->append("dc_read Error!");
        return;
    }
    else
    {
        memset(rdatahex, 0x00, sizeof(rdatahex));
        hex_a(rdata, rdatahex, 16);
        std::string str1 = (char*)rdatahex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    safeExit:
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}

void MainWindow::on_pushButton_6_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    unsigned char _Snr[100] = "\0";
    unsigned char szSnr[100] = "\0";
    unsigned int SnrLen = 0;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    unsigned char key[17] = "\0";
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    unsigned char rdata[100] = "\0";
    unsigned char rdatahex[100] = "\0";
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    //射频复位
    dc_reset(icdev, 1);
    st = dc_card_n(icdev, 0, &SnrLen, _Snr);
    if (st != 0)
    {
        ui->textEdit->append("dc_card_n Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_card_n Ok!");
        memset(szSnr, 0x00, sizeof(szSnr));
        hex_a(_Snr, szSnr, SnrLen);
        std::string str1 = (char*)szSnr;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }

    memcpy(key, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF", 16);
    st = dc_auth_ulc(icdev, key);
    if (st)
    {
        ui->textEdit->append("dc_auth_ulc erro");
        goto safeExit;
        return;
    }
    ui->textEdit->append("dc_auth_ulc ok");
    st = dc_write(icdev, 4, (unsigned char*)"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x31\x32\x33\x34\x35\x36");
    if (st != 0)
    {
        ui->textEdit->append("dc_write Error!");
        goto safeExit;
        return;
    }
    else
        ui->textEdit->append("dc_write OK!");
    //读扇�
    st = dc_read(icdev, 4, rdata);
    if (st != 0)
    {
        ui->textEdit->append("dc_read Error!");
        goto safeExit;
        return;
    }
    else
    {
        memset(rdatahex, 0x00, sizeof(rdatahex));
        hex_a(rdata, rdatahex, 16);
        std::string str1 = (char*)rdatahex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
safeExit:
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}

void MainWindow::on_pushButton_9_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    unsigned char databuffer[100] = "\0";
    unsigned char databufferhex[100] = "\0";
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    unsigned char writedata[100] = "\0";
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    //射频复位

    st = dc_verifypin_4442(icdev, (unsigned char *)"\xFF\xFF\xFF");
    for (int i = 0; i < 50; i++)
        writedata[i] = rand() % 0xFF;
    st = dc_write_4442(icdev, 32, 50, writedata);
    if (st)
    {
        ui->textEdit->append("dc_write_4442 Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_write_4442 Ok!");
    }

    st = dc_read_4442(icdev, 32, 50, databuffer);
    if (st)
    {
        ui->textEdit->append("dc_read_4442 Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_read_4442 Ok!");
        hex_a(databuffer, databufferhex, 50);
        std::string str1 = (char*)databufferhex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    safeExit:
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}

void MainWindow::on_pushButton_11_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    unsigned char writedata[100] = "\0";
    unsigned char databuffer[100] = "\0";
    unsigned char databufferhex[100] = "\0";
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    st = dc_verifypin_4428(icdev, (unsigned char *)"\xFF\xFF");

    for (int i = 0; i < 50; i++)
        writedata[i] = rand() % 0xFF;
    st = dc_write_4428(icdev, 32, 50, writedata);
    if (st)
    {
        ui->textEdit->append("dc_write_4428 Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_write_4428 Ok!");
    }

    st = dc_read_4428(icdev, 32, 50, databuffer);
    if (st)
    {
        ui->textEdit->append("dc_read_4428 Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_read_4428 Ok! Error!");
        hex_a(databuffer, databufferhex, 50);
        std::string str1 = (char*)databufferhex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    safeExit:
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}

void MainWindow::on_pushButton_12_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    unsigned char writedata[100] = "\0";
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    unsigned char databuffer[100] = "\0";
    unsigned char databufferhex[100] = "\0";
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    st = dc_setcpu(icdev, 0x0C); //附卡�
    if (st != 0)
    {
        ui->textEdit->append("dc_setcpu Error!");
        goto safeExit;
        return;
    }

    for (int i = 0; i < 50; i++)
        writedata[i] = rand() % 0xFF;
    st = dc_write_24c(icdev, 32, 50, writedata);
    if (st)
    {
        ui->textEdit->append("dc_write_24c Error!");
        goto safeExit;
        return;
    }
    ui->textEdit->append("dc_write_24c ok!");

    st = dc_read_24c(icdev, 32, 50, databuffer);
    if (st)
    {
        ui->textEdit->append("dc_read_24c Error!");
        goto safeExit;
        return;
    }
    else
    {
        ui->textEdit->append("dc_read_24c Ok!");
        hex_a(databuffer, databufferhex, 50);
        std::string str1 = (char*)databufferhex;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
    }
    safeExit:
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}

void MainWindow::on_pushButton_10_clicked()
{
    // TODO: 在此添加控件通知处理程序代码
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    unsigned char rlen = 0;
    unsigned char recdata[512] = "\0";
    unsigned char recdatahex[512] = "\0";
    unsigned int rlen1 = 0;
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    std::string str1;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    st = dc_setcpu(icdev, 0x0C);   //2005-2-25
    if (st)
    {
        ui->textEdit->append("dc_setcpu Error!");
        goto safeExit;
        return;
    }

    st = dc_cpureset(icdev, &rlen, recdata);
    if (st)
    {
        ui->textEdit->append("dc_cpureset Error!");
        goto safeExit;
        return;
    }
    ui->textEdit->append("dc_cpureset Ok!");
    hex_a(recdata, recdatahex, (short)rlen);
    str1 = (char*)recdatahex;
    str = QString::fromStdString(str1);
    ui->textEdit->append(str);
    memset(recdata, 0x00, sizeof(recdata));
    memset(recdatahex, 0x00, sizeof(recdatahex));
    st = dc_cpuapduInt(icdev, 5, (unsigned char *)"\x00\x84\x00\x00\x08", &rlen1, recdata);
    if (st)
    {
        ui->textEdit->append("dc_cpuapduInt Error!");
        goto safeExit;
        return;
    }
    ui->textEdit->append("dc_cpuapduInt Ok!");
    hex_a(recdata, recdatahex, (short)rlen1);
    str1 = (char*)recdatahex;
    str = QString::fromStdString(str1);
    ui->textEdit->append(str);
    safeExit:
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}

void MainWindow::on_pushButton_13_clicked()
{
    QPixmap p;
    int st = -1;
    HANDLE icdev = (HANDLE)-1;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    QTextCodec *codec = QTextCodec::codecForName("GB2312");
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    dc_beep(icdev, 10);
        int result;
        int text_len;
        unsigned char text[256];
        int photo_len;
        unsigned char photo[1024];
        int fingerprint_len;
        unsigned char fingerprint[1024];
        int extra_len;
        unsigned char extra[70];
        int type = 0;
        char tempbuffer[1024] = "\0";
        ui->textEdit->append("-------- Read ID INFORMATION--------");

        ui->textEdit->append("dc_SamAReadCardInfo ... ");
        result = dc_SamAReadCardInfo(icdev, 3, &text_len, text, &photo_len, photo, &fingerprint_len, fingerprint, &extra_len, extra);
        if (result != 0) {
            ui->textEdit->append(" dc_SamAReadCardInfo error!");
            goto safeExit;
            return;
        }
        ui->textEdit->append("dc_SamAReadCardInfo ok!");

        if ((text[0] >= 'A') && (text[0] <= 'Z') && (text[1] == 0)) {
            type = 1;
        }

        if (type == 0) {
            unsigned char name[64];
            unsigned char sex[8];
            unsigned char nation[12];
            unsigned char birth_day[36];
            unsigned char address[144];
            unsigned char id_number[76];
            unsigned char department[64];
            unsigned char expire_start_day[36];
            unsigned char expire_end_day[36];
            unsigned char reserved[76];
            unsigned char info_buffer[64];

            ui->textEdit->append("dc_ParseTextInfo ... ");
            result = dc_ParseTextInfo(icdev, 0, text_len, text, name, sex, nation, birth_day, address, id_number, department, expire_start_day, expire_end_day, reserved);
            if (result != 0) {
                ui->textEdit->append("dc_ParseTextInfo error!");
                goto safeExit;
                return;
            }
            ui->textEdit->append("dc_ParseTextInfo ok!");

            sprintf(tempbuffer,"name: %s", name);

            ui->textEdit->append(codec->toUnicode(tempbuffer));
            dc_ParseOtherInfo(icdev, 0, sex, info_buffer);

            sprintf(tempbuffer,"sex: %s", info_buffer);
            ui->textEdit->append(codec->toUnicode(tempbuffer));
            dc_ParseOtherInfo(icdev, 1, nation, info_buffer);

            sprintf(tempbuffer,"nation: %s", info_buffer);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"birth_day: %s", birth_day);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"address: %s", address);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"id_number: %s", id_number);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"department: %s", department);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"expire_start_day: %s", expire_start_day);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"expire_end_day: %s", expire_end_day);
            ui->textEdit->append(codec->toUnicode(tempbuffer));
        }
        else if (type == 1) {
            unsigned char english_name[244];
            unsigned char sex[8];
            unsigned char id_number[64];
            unsigned char citizenship[16];
            unsigned char chinese_name[64];
            unsigned char expire_start_day[36];
            unsigned char expire_end_day[36];
            unsigned char birth_day[36];
            unsigned char version_number[12];
            unsigned char department_code[20];
            unsigned char type_sign[8];
            unsigned char reserved[16];
            unsigned char info_buffer[64];


            ui->textEdit->append("dc_ParseTextInfoForForeigner ... ");
            result = dc_ParseTextInfoForForeigner(icdev, 0, text_len, text, english_name, sex, id_number, citizenship, chinese_name, expire_start_day, expire_end_day, birth_day, version_number, department_code, type_sign, reserved);
            if (result != 0) {
                ui->textEdit->append("dc_ParseTextInfoForForeigner error!");
                goto safeExit;
                return;
            }
            ui->textEdit->append("dc_ParseTextInfoForForeigner ok!");

            sprintf(tempbuffer,"english_name: %s", english_name);
            ui->textEdit->append(codec->toUnicode(tempbuffer));
            dc_ParseOtherInfo(icdev, 0, sex, info_buffer);

            sprintf(tempbuffer,"sex�s/%s", info_buffer, (strcmp((char *)sex, "1") == 0) ? "M" : "F");
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"id_number: %s", id_number);
            ui->textEdit->append(codec->toUnicode(tempbuffer));
            dc_ParseOtherInfo(icdev, 2, citizenship, info_buffer);

            sprintf(tempbuffer,"citizenship: %s/%s", info_buffer, citizenship);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"chinese_name: %s", chinese_name);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"expire_start_day: %s", expire_start_day);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"expire_end_day: %s", expire_end_day);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"birth_day: %s", birth_day);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"version_number: %s", version_number);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"department_code: %s", department_code);
            ui->textEdit->append(codec->toUnicode(tempbuffer));

            sprintf(tempbuffer,"type_sign: %s", type_sign);
            ui->textEdit->append(codec->toUnicode(tempbuffer));
        }

        ui->textEdit->append("dc_ParsePhotoInfo ... ");
        result = dc_ParsePhotoInfo(icdev, 0, photo_len, photo, 0, (unsigned char *)"me.bmp");
        if (result != 0) {
            goto safeExit;
        }
        p.load("me.bmp");
        ui->label_9->setPixmap(p);
        ui->textEdit->append("dc_ParsePhotoInfo ok!");
        ui->textEdit->append("dc_IdCardImageBuild ... ");
        result = dc_IdCardImageBuild(icdev, type, text_len, text, photo_len, photo, "front.bmp", "back.bmp");
        if (result != 0) {
            ui->textEdit->append("dc_IdCardImageBuild error!");
            goto safeExit;
            return;
        }
        ui->textEdit->append("dc_IdCardImageBuild ok!");
    safeExit:
        if ((int)icdev > 0)
        {
            st = dc_exit(icdev);
            if (st != 0)
            {
                ui->textEdit->append("dc_exit Error!");
                return;
            }
            else
            {
                ui->textEdit->append("dc_exit OK!");
                icdev = (HANDLE)-1;
            }
        }
}

void MainWindow::on_pushButton_14_clicked()
{
    HANDLE icdev = (HANDLE)-1;
    int st = -1;
    int ibaund = 0;
    int iport = 0;
    QString strport;
    QString strbaund;
    QString str;
    strport = ui->comboBox->currentText();
    strbaund = ui->comboBox_2->currentText();
    bool ok;
    std::string str1;
    ibaund = strbaund.toInt(&ok,10); //dec=255 ; ok=rue
    if(strport == "usb")
        iport = 100;
    else if (strport == "com1")
    {
        iport = 0;
    }
    else if (strport == "com2")
    {
        iport = 1;
    }
    else if (strport == "com3")
    {
        iport = 2;
    }
    icdev = dc_init(iport, ibaund);
    if ((int)icdev <= 0)
    {
        ui->textEdit->append("Init Com Error!");
        return;
    }
    else
    {
        ui->textEdit->append("Init Com OK!");
    }
    dc_beep(icdev, 10);
    int result;
      unsigned char buffer[8192], buffer2[8192 + 1];
      int len;

      int times = 30;
      times *= 1000;
      int ms;

      result = dc_Scan2DBarcodeStart(icdev, 0x00);
      if (result != 0)
      {
          ui->textEdit->append("dc_Scan2DBarcodeStart Error!");
          goto safeExit;
      }
      while (true)
      {
          ms = GetTickCount();
          Sleep(10);
          result = dc_Scan2DBarcodeGetData(icdev, &len, buffer);
          if (result == 0)
          {
              break;
          }
        if ((times -= (GetTickCount() - ms)) <= 0)
        {
          result = -2;
        }
      }
      dc_Scan2DBarcodeExit(icdev);

      if (result == 0)
      {
        memcpy(buffer2, buffer, len);
        buffer2[len] = '\0';
        str1 = (char*)buffer2;
        str = QString::fromStdString(str1);
        ui->textEdit->append(str);
      }
      else if (result == -2)
      {
        ui->textEdit->append("time out!");
      }

    safeExit:
    if ((int)icdev > 0)
    {
        st = dc_exit(icdev);
        if (st != 0)
        {
            ui->textEdit->append("dc_exit Error!");
            return;
        }
        else
        {
            ui->textEdit->append("dc_exit OK!");
            icdev = (HANDLE)-1;
        }
    }
    return;
}
