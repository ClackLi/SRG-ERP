#include "stdafx.h"
#include "Sel4428.h"

void Sel4428()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	HANDLE icdev = (HANDLE)-1;
	int st = -1;
	unsigned char _Snr[100] = "\0";
	unsigned char szSnr[100] = "\0";
	unsigned int SnrLen = 0;
	CString str = _T("");
	int ibaund = 0;
	HWND hWnd = ::FindWindow(NULL, _T("T10demo"));
	CWnd* pWnd = AfxGetApp()->GetMainWnd();
	CdemoDlg *t10DemoDlg = (CdemoDlg*)CWnd::FromHandle(hWnd);

	pWnd->GetDlgItemText(IDC_COMBO1, str);
	ibaund = pWnd->GetDlgItemInt(IDC_COMBO2);
	if (str == "usb")
		icdev = dc_init(100, ibaund);
	else if (str == "PSCS")
	{
		icdev = dc_init(200, ibaund);
	}
	else if (str == "com1")
	{
		icdev = dc_init(0, ibaund);
	}
	else if (str == "com2")
	{
		icdev = dc_init(1, ibaund);
	}
	else if (str == "com3")
	{
		icdev = dc_init(2, ibaund);
	}
	if ((int)icdev <= 0)
	{
		t10DemoDlg->AddEdit(_T("Init Com Error!"));
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("Init Com OK!"));
	}
	dc_beep(icdev, 10);
	st = dc_verifypin_4428(icdev, (unsigned char *)"\xFF\xFF");
	if (st)
	{
		t10DemoDlg->AddEdit(_T("dc_verifypin_4428 Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_verifypin_4428 Ok!"));
	}
	unsigned char writedata[200] = "\0";
	for (int i = 0; i < 50; i++)
		writedata[i] = rand() % 0xFF;
	st = dc_write_4428(icdev, 32, 50, writedata);
	if (st)
	{
		t10DemoDlg->AddEdit(_T("dc_verifypin_4428 Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_verifypin_4428 Ok!"));
	}
	unsigned int rlen = 0;
	unsigned char databuffer[200] = "\0";
	unsigned char databufferhex[200] = "\0";
	st = dc_read_4428(icdev, 32, 50, databuffer);
	if (st)
	{
		t10DemoDlg->AddEdit(_T("dc_read_4428 Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_read_4428 Ok!"));
		hex_a(databuffer, databufferhex, 50);
		t10DemoDlg->AddEdit((LPCSTR)databufferhex);
	}
safeExit:
	if ((int)icdev > 0)
	{
		st = dc_exit(icdev);
		if (st != 0)
		{
			t10DemoDlg->AddEdit(_T("dc_exit Error!"));
			return;
		}
		else
		{
			t10DemoDlg->AddEdit(_T("dc_exit OK!"));
			icdev = (HANDLE)-1;
		}
	}
	return;
}