#include "stdafx.h"
#include "Cpu.h"

void Cpu()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	HANDLE icdev = (HANDLE)-1;
	int st = -1;
	unsigned char _Snr[100] = "\0";
	unsigned char szSnr[100] = "\0";
	unsigned int SnrLen = 0;
	CString str = _T("");
	int ibaund = 0;
	HWND hWnd = ::FindWindow(NULL, _T("T10demo"));
	CWnd* pWnd = AfxGetApp()->GetMainWnd();
	CdemoDlg *t10DemoDlg = (CdemoDlg*)CWnd::FromHandle(hWnd);

	pWnd->GetDlgItemText(IDC_COMBO1, str);
	ibaund = pWnd->GetDlgItemInt(IDC_COMBO2);
	if (str == "usb")
		icdev = dc_init(100, ibaund);
	else if (str == "PSCS")
	{
		icdev = dc_init(200, ibaund);
	}
	else if (str == "com1")
	{
		icdev = dc_init(0, ibaund);
	}
	else if (str == "com2")
	{
		icdev = dc_init(1, ibaund);
	}
	else if (str == "com3")
	{
		icdev = dc_init(2, ibaund);
	}
	if ((int)icdev <= 0)
	{
		t10DemoDlg->AddEdit(_T("Init Com Error!"));
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("Init Com OK!"));
	}
	dc_beep(icdev, 10);
	st = dc_setcpu(icdev, 0x0C);   //2005-2-25
	if (st)
	{
		t10DemoDlg->AddEdit(_T("dc_setcpu Error!"));
		goto safeExit;
		return;
	}
	unsigned char rlen = 0;
	unsigned char recdata[512] = "\0";
	unsigned char recdatahex[512] = "\0";
	unsigned int rlen1;
	st = dc_cpureset(icdev, &rlen, recdata);
	if (st)
	{
		t10DemoDlg->AddEdit(_T("dc_cpureset Error!"));
		goto safeExit;
		return;
	}
	t10DemoDlg->AddEdit(_T("dc_cpureset Ok!"));
	hex_a(recdata, recdatahex, (short)rlen);
	t10DemoDlg->AddEdit((LPCSTR)recdatahex);
	memset(recdata, 0x00, sizeof(recdata));
	memset(recdatahex, 0x00, sizeof(recdatahex));
	st = dc_cpuapduInt(icdev, 5, (unsigned char *)"\x00\x84\x00\x00\x08", &rlen1, recdata);
	if (st)
	{
		t10DemoDlg->AddEdit(_T("dc_cpuapduInt Error!"));
		goto safeExit;
		return;
	}
	t10DemoDlg->AddEdit(_T("dc_cpuapduInt Ok!"));
	hex_a(recdata, recdatahex, (short)rlen1);
	t10DemoDlg->AddEdit((LPCSTR)recdatahex);
safeExit:
	if ((int)icdev > 0)
	{
		st = dc_exit(icdev);
		if (st != 0)
		{
			t10DemoDlg->AddEdit(_T("dc_exit Error!"));
			return;
		}
		else
		{
			t10DemoDlg->AddEdit(_T("dc_exit OK!"));
			icdev = (HANDLE)-1;
		}
	}
	return;
}