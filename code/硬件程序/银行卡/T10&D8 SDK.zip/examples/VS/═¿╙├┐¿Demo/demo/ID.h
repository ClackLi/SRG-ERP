#pragma once
#include "stdafx.h"
#include "demoDlg.h"
#include "demo.h"

void IDRead();