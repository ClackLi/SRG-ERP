#include "stdafx.h"
#include "Ultralight.h"

void ultraLight()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	HANDLE icdev = (HANDLE)-1;
	int st = -1;
	unsigned char _Snr[100] = "\0";
	unsigned char szSnr[100] = "\0";
	unsigned int SnrLen = 0;
	CString str = _T("");
	int ibaund = 0;
	HWND hWnd = ::FindWindow(NULL, _T("T10demo"));
	CWnd* pWnd = AfxGetApp()->GetMainWnd();
	CdemoDlg *t10DemoDlg = (CdemoDlg*)CWnd::FromHandle(hWnd);

	pWnd->GetDlgItemText(IDC_COMBO1, str);
	ibaund = pWnd->GetDlgItemInt(IDC_COMBO2);
	if (str == "usb")
		icdev = dc_init(100, ibaund);
	else if (str == "PSCS")
	{
		icdev = dc_init(200, ibaund);
	}
	else if (str == "com1")
	{
		icdev = dc_init(0, ibaund);
	}
	else if (str == "com2")
	{
		icdev = dc_init(1, ibaund);
	}
	else if (str == "com3")
	{
		icdev = dc_init(2, ibaund);
	}
	if ((int)icdev <= 0)
	{
		t10DemoDlg->AddEdit(_T("Init Com Error!"));
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("Init Com OK!"));
	}
	dc_beep(icdev, 10);
	//��Ƶ��λ
	dc_reset(icdev, 1);
	st = dc_card_n(icdev, 0, &SnrLen, _Snr);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Ok!"));
		memset(szSnr, 0x00, sizeof(szSnr));
		hex_a(_Snr, szSnr, SnrLen);
		t10DemoDlg->AddEdit((LPCSTR)szSnr);
	}
	st = dc_write(icdev, 4, (unsigned char*)"\x31\x32\x33\x34\x35\x36\x37\x38\x39\x30\x31\x32\x33\x34\x35\x36");
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_write Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_write OK!"));
	}
	unsigned char rdata[100] = "\0";
	unsigned char rdatahex[100] = "\0";
	//������
	st = dc_read(icdev, 4, rdata);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_read Error!"));
		goto safeExit;
		return;
	}
	else
	{
		memset(rdatahex, 0x00, sizeof(rdatahex));
		hex_a(rdata, rdatahex, 16);
		t10DemoDlg->AddEdit((LPCSTR)rdatahex);
	}
safeExit:
	if ((int)icdev > 0)
	{
		st = dc_exit(icdev);
		if (st != 0)
		{
			t10DemoDlg->AddEdit(_T("dc_exit Error!"));
			return;
		}
		else
		{
			t10DemoDlg->AddEdit(_T("dc_exit OK!"));
			icdev = (HANDLE)-1;
		}
	}
	return;
}

void ultraLightC()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	HANDLE icdev = (HANDLE)-1;
	int st = -1;
	unsigned char _Snr[100] = "\0";
	unsigned char szSnr[100] = "\0";
	unsigned int SnrLen = 0;
	CString str = _T("");
	int ibaund = 0;
	HWND hWnd = ::FindWindow(NULL, _T("T10demo"));
	CWnd* pWnd = AfxGetApp()->GetMainWnd();
	CdemoDlg *t10DemoDlg = (CdemoDlg*)CWnd::FromHandle(hWnd);

	pWnd->GetDlgItemText(IDC_COMBO1, str);
	ibaund = pWnd->GetDlgItemInt(IDC_COMBO2);
	if (str == "usb")
		icdev = dc_init(100, ibaund);
	else if (str == "PSCS")
	{
		icdev = dc_init(200, ibaund);
	}
	else if (str == "com1")
	{
		icdev = dc_init(0, ibaund);
	}
	else if (str == "com2")
	{
		icdev = dc_init(1, ibaund);
	}
	else if (str == "com3")
	{
		icdev = dc_init(2, ibaund);
	}
	if ((int)icdev <= 0)
	{
		t10DemoDlg->AddEdit(_T("Init Com Error!"));
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("Init Com OK!"));
	}
	dc_beep(icdev, 10);
	//��Ƶ��λ
	dc_reset(icdev, 1);
	st = dc_card_n(icdev, 0, &SnrLen, _Snr);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Ok!"));
		memset(szSnr, 0x00, sizeof(szSnr));
		hex_a(_Snr, szSnr, SnrLen);
		t10DemoDlg->AddEdit((LPCSTR)szSnr);
	}
	unsigned char key[17] = "\0";
	int nRet(0);
	memcpy(key, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF", 16);
	nRet = dc_auth_ulc(icdev, key);
	if (nRet)
	{
		t10DemoDlg->AddEdit(_T("dc_auth_ulc erro"));
		goto safeExit;
		return;
	}
	t10DemoDlg->AddEdit(_T("dc_auth_ulc ok"));
	st = dc_write(icdev, 1, (unsigned char*)"\x33\x34\x35\x36");
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_write Error!"));
		goto safeExit;
		return;
	}
	else
		t10DemoDlg->AddEdit(_T("dc_write OK!"));
	unsigned char rdata[100] = "\0";
	unsigned char rdatahex[100] = "\0";
	//������
	st = dc_read(icdev, 1, rdata);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_read Error!"));
		goto safeExit;
		return;
	}
	else
	{
		memset(rdatahex, 0x00, sizeof(rdatahex));
		hex_a(rdata, rdatahex, 16);
		t10DemoDlg->AddEdit((LPCSTR)rdatahex);
	}
safeExit:
	if ((int)icdev > 0)
	{
		st = dc_exit(icdev);
		if (st != 0)
		{
			t10DemoDlg->AddEdit(_T("dc_exit Error!"));
			return;
		}
		else
		{
			t10DemoDlg->AddEdit(_T("dc_exit OK!"));
			icdev = (HANDLE)-1;
		}
	}
	return;
}