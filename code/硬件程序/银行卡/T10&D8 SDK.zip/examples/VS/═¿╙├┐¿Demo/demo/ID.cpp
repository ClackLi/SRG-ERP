#include "stdafx.h"
#include "ID.h"

static HBITMAP LoadAnImage(const unsigned char *data, unsigned long len)
{
	HGLOBAL hG;
	IStream *s;
	IPicture *p;
	HBITMAP hB, hBB;

	hG = GlobalAlloc(GPTR, len);
	if (!hG)
	{
		return NULL;
	}

	memcpy(hG, data, len);

	if (CreateStreamOnHGlobal(hG, FALSE, &s) != S_OK)
	{
		GlobalFree(hG);
		return NULL;
	}

	if (OleLoadPicture(s, 0, FALSE, IID_IPicture, (void **)&p) != S_OK)
	{
		s->Release();
		GlobalFree(hG);
		return NULL;
	}

	s->Release();
	GlobalFree(hG);

	p->get_Handle((OLE_HANDLE *)&hB);
	hBB = (HBITMAP)CopyImage(hB, IMAGE_BITMAP, 0, 0, LR_COPYRETURNORG);
	p->Release();

	return hBB;
}

void IDRead()
{
	HANDLE icdev = (HANDLE)-1;
	int st = -1;
	unsigned char _Snr[100] = "\0";
	unsigned char szSnr[100] = "\0";
	unsigned int SnrLen = 0;
	CString str = _T("");
	int ibaund = 0;
	HWND hWnd = ::FindWindow(NULL, _T("T10demo"));
	CWnd* pWnd = AfxGetApp()->GetMainWnd();
	CdemoDlg *t10DemoDlg = (CdemoDlg*)CWnd::FromHandle(hWnd);

	pWnd->GetDlgItemText(IDC_COMBO1, str);
	ibaund = pWnd->GetDlgItemInt(IDC_COMBO2);
	if (str == "usb")
		icdev = dc_init(100, ibaund);
	else if (str == "PSCS")
	{
		icdev = dc_init(200, ibaund);
	}
	else if (str == "com1")
	{
		icdev = dc_init(0, ibaund);
	}
	else if (str == "com2")
	{
		icdev = dc_init(1, ibaund);
	}
	else if (str == "com3")
	{
		icdev = dc_init(2, ibaund);
	}
	if ((int)icdev <= 0)
	{
		t10DemoDlg->AddEdit(_T("Init Com Error!"));
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("Init Com OK!"));
	}
	dc_beep(icdev, 10);
	int result;
	int text_len;
	unsigned char text[256];
	int photo_len;
	unsigned char photo[1024];
	int fingerprint_len;
	unsigned char fingerprint[1024];
	int extra_len;
	unsigned char extra[70];
	int type = 0;
	char tempbuffer[1024] = "\0";

	t10DemoDlg->AddEdit(_T("\n-------- Read ID INFORMATION--------\n"));

	t10DemoDlg->AddEdit("dc_SamAReadCardInfo ...\n ");
	result = dc_SamAReadCardInfo(icdev, 3, &text_len, text, &photo_len, photo, &fingerprint_len, fingerprint, &extra_len, extra);
	if (result != 0) {
		t10DemoDlg->AddEdit(" dc_SamAReadCardInfo error!\n");
		goto safeExit;
		return;
	}
	t10DemoDlg->AddEdit(_T("dc_SamAReadCardInfo ok!\n"));

	if ((text[0] >= 'A') && (text[0] <= 'Z') && (text[1] == 0)) {
		type = 1;
	}

	if (type == 0) {
		unsigned char name[64];
		unsigned char sex[8];
		unsigned char nation[12];
		unsigned char birth_day[36];
		unsigned char address[144];
		unsigned char id_number[76];
		unsigned char department[64];
		unsigned char expire_start_day[36];
		unsigned char expire_end_day[36];
		unsigned char reserved[76];
		unsigned char info_buffer[64];

		t10DemoDlg->AddEdit(_T("dc_ParseTextInfo ... \n"));
		result = dc_ParseTextInfo(icdev, 0, text_len, text, name, sex, nation, birth_day, address, id_number, department, expire_start_day, expire_end_day, reserved);
		if (result != 0) {
			t10DemoDlg->AddEdit(_T("dc_ParseTextInfo error!\n"));
			goto safeExit;
			return;
		}
		t10DemoDlg->AddEdit(_T("dc_ParseTextInfo ok!\n"));
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "name: %s\n", name);
		t10DemoDlg->AddEdit(tempbuffer);
		dc_ParseOtherInfo(icdev, 0, sex, info_buffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "sex: %s\n", info_buffer);
		t10DemoDlg->AddEdit(tempbuffer);
		dc_ParseOtherInfo(icdev, 1, nation, info_buffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "nation: %s\n", info_buffer);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "birth_day: %s\n", birth_day);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "address: %s\n", address);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "id_number: %s\n", id_number);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "department: %s\n", department);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "expire_start_day: %s\n", expire_start_day);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "expire_end_day: %s\n", expire_end_day);
		t10DemoDlg->AddEdit(tempbuffer);
	}
	else if (type == 1) {
		unsigned char english_name[244];
		unsigned char sex[8];
		unsigned char id_number[64];
		unsigned char citizenship[16];
		unsigned char chinese_name[64];
		unsigned char expire_start_day[36];
		unsigned char expire_end_day[36];
		unsigned char birth_day[36];
		unsigned char version_number[12];
		unsigned char department_code[20];
		unsigned char type_sign[8];
		unsigned char reserved[16];
		unsigned char info_buffer[64];
		

		t10DemoDlg->AddEdit(_T("dc_ParseTextInfoForForeigner ... \n"));
		result = dc_ParseTextInfoForForeigner(icdev, 0, text_len, text, english_name, sex, id_number, citizenship, chinese_name, expire_start_day, expire_end_day, birth_day, version_number, department_code, type_sign, reserved);
		if (result != 0) {
			t10DemoDlg->AddEdit(_T("dc_ParseTextInfoForForeigner error!\n"));
			goto safeExit;
			return;
		}
		t10DemoDlg->AddEdit(_T("dc_ParseTextInfoForForeigner ok!\n"));
		memset(tempbuffer,0x00,sizeof(tempbuffer));
		sprintf_s(tempbuffer, "english_name: %s\n", english_name);
		t10DemoDlg->AddEdit(tempbuffer);
		dc_ParseOtherInfo(icdev, 0, sex, info_buffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "sex��%s/%s\n", info_buffer, (strcmp((char *)sex, "1") == 0) ? "M" : "F");
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "id_number: %s\n", id_number);
		t10DemoDlg->AddEdit(tempbuffer);
		dc_ParseOtherInfo(icdev, 2, citizenship, info_buffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "citizenship: %s/%s\n", info_buffer, citizenship);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "chinese_name: %s\n", chinese_name);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "expire_start_day: %s\n", expire_start_day);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "expire_end_day: %s\n", expire_end_day);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "birth_day: %s\n", birth_day);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "version_number: %s\n", version_number);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "department_code: %s\n", department_code);
		t10DemoDlg->AddEdit(tempbuffer);
		memset(tempbuffer, 0x00, sizeof(tempbuffer));
		sprintf_s(tempbuffer, "type_sign: %s\n", type_sign);
		t10DemoDlg->AddEdit(tempbuffer);
	}

	t10DemoDlg->AddEdit(_T("dc_ParsePhotoInfo ... \n"));
	result = dc_ParsePhotoInfo(icdev, 0, photo_len, photo, 0, (unsigned char *)"me.bmp");
	if (result != 0) {
		goto safeExit;
	}
	t10DemoDlg->AddEdit(_T("dc_ParsePhotoInfo error!\n"));
	//pWnd->Set;
	/*HBITMAP bitmap;
	bitmap = LoadAnImage(photo, photo_len);
	if (bitmap)
	{
		t10DemoDlg->GetDlgItem(IDC_PICTURE)->Invalidate();
		t10DemoDlg->GetDlgItem(IDC_PICTURE)->UpdateWindow();
	}*/
	CStatic *pwnd = (CStatic*)(t10DemoDlg->GetDlgItem(IDC_PICTURE));
	pwnd->ModifyStyle(0xf, SS_BITMAP | SS_CENTERIMAGE);
	pwnd->SetBitmap((HBITMAP)::LoadImage(NULL,
		_T("me.bmp"),// ������Դ�Ż򱾵��ļ���  
		IMAGE_BITMAP,                                  // װ��λͼIMAGE_CURSOR���IMAGE_ICONͼ��  
		0,                                             // ����0ΪĬ�ϴ�С  
		0,                                             // �߶�����Ϊ��λ  
		LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE));
	t10DemoDlg->AddEdit(_T("dc_ParsePhotoInfo ok!\n"));

#ifdef WIN32
#ifndef _WIN64
	t10DemoDlg->AddEdit(_T("dc_IdCardImageBuild ... "));
	result = dc_IdCardImageBuild(icdev, type, text_len, text, photo_len, photo, "front.bmp", "back.bmp");
	if (result != 0) {
		t10DemoDlg->AddEdit(_T("dc_IdCardImageBuild error!\n"));
		goto safeExit;
		return;
	}
	t10DemoDlg->AddEdit(_T("dc_IdCardImageBuild ok!\n"));
#endif
#endif
safeExit:
	if ((int)icdev > 0)
	{
		st = dc_exit(icdev);
		if (st != 0)
		{
			t10DemoDlg->AddEdit(_T("dc_exit Error!"));
			return;
		}
		else
		{
			t10DemoDlg->AddEdit(_T("dc_exit OK!"));
			icdev = (HANDLE)-1;
		}
	}
}
