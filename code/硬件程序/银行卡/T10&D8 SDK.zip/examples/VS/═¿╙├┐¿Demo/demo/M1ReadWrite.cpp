#include "stdafx.h"
#include "M1ReadWrite.h"

void M1ReadWrite()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	HANDLE icdev=(HANDLE)-1;
	int st = -1;
	unsigned char _Snr[100] = "\0";
	unsigned char szSnr[100] = "\0";
	unsigned int SnrLen = 0;
	CString str = _T("");
	int ibaund = 0;
	HWND hWnd = ::FindWindow(NULL,_T("T10demo"));
	CWnd* pWnd = AfxGetApp()->GetMainWnd();
	CdemoDlg *t10DemoDlg = (CdemoDlg*)CWnd::FromHandle(hWnd);

	pWnd->GetDlgItemText(IDC_COMBO1, str);
	ibaund = pWnd->GetDlgItemInt(IDC_COMBO2);
	if (str == "usb")
		icdev = dc_init(100, ibaund);
	else if (str == "PSCS")
	{
		icdev = dc_init(200, ibaund);
	}
	else if (str == "com1")
	{
		icdev = dc_init(0, ibaund);
	}
	else if (str == "com2")
	{
		icdev = dc_init(1, ibaund);
	}
	else if (str == "com3")
	{
		icdev = dc_init(2, ibaund);
	}
	if ((int)icdev <= 0)
	{
		t10DemoDlg->AddEdit(_T("Init Com Error!"));
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("Init Com OK!"));
	}
	dc_beep(icdev, 10);
	//��Ƶ��λ
	dc_reset(icdev, 1);
	//���ÿ���
	st = dc_config_card(icdev, 'A');
	//Ѱ�������ؿ����к�
	st = dc_card_n(icdev, 0, &SnrLen, _Snr);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Ok!"));
		/*for (int i = 0; i < 4; i++)
		{
			_Snr[i] = _Snr[3 - i];
		}*/
		memset(szSnr, 0x00, sizeof(szSnr));
		hex_a(_Snr, szSnr, 4);
		t10DemoDlg->AddEdit((LPCTSTR)szSnr);
	}
	//��֤������
	st = dc_authentication_passaddr(icdev, 0, 7, (unsigned char *)"\xFF\xFF\xFF\xFF\xFF\xFF");
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_authentication_passaddr Error!"));
		goto safeExit;
		return;
	}
	else
		t10DemoDlg->AddEdit(_T("dc_authentication_passaddr OK!"));
	//д����
	st = dc_write(icdev, 4, (unsigned char*)"\x31\x32\x33\x34\x35\x36\x37\x38\x39\x30\x31\x32\x33\x34\x35\x36");
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_write Error!"));
		goto safeExit;
		return;
	}
	else
		t10DemoDlg->AddEdit(_T("dc_write OK!"));
	unsigned char rdata[100] = "\0";
	unsigned char rdatahex[100] = "\0";
	//������
	st = dc_read(icdev, 4, rdata);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_read Error!"));
		goto safeExit;
		return;
	}
	else
	{
		memset(rdatahex, 0x00, sizeof(rdatahex));
		hex_a(rdata, rdatahex, 16);
		t10DemoDlg->AddEdit((LPCTSTR)rdatahex);
	}
safeExit:
	if ((int)icdev > 0)
	{
		st = dc_exit(icdev);
		if (st != 0)
		{
			t10DemoDlg->AddEdit(_T("dc_exit Error!"));
			return;
		}
		else
		{
			t10DemoDlg->AddEdit(_T("dc_exit OK!"));
			icdev = (HANDLE)-1;
		}
	}
	return;
}

void M1Value()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	HANDLE icdev = (HANDLE)-1;
	int st = -1;
	unsigned char _Snr[100] = "\0";
	unsigned char szSnr[100] = "\0";
	unsigned int SnrLen = 0;
	unsigned int uivalue = 0;
	char cvalue[100] = "\0";
	CString str = _T("");
	int ibaund = 0;
	HWND hWnd = ::FindWindow(NULL, _T("T10demo"));
	CWnd* pWnd = AfxGetApp()->GetMainWnd();
	CdemoDlg *t10DemoDlg = (CdemoDlg*)CWnd::FromHandle(hWnd);

	pWnd->GetDlgItemText(IDC_COMBO1, str);
	ibaund = pWnd->GetDlgItemInt(IDC_COMBO2);
	if (str == "usb")
		icdev = dc_init(100, ibaund);
	else if (str == "PSCS")
	{
		icdev = dc_init(200, ibaund);
	}
	else if (str == "com1")
	{
		icdev = dc_init(0, ibaund);
	}
	else if (str == "com2")
	{
		icdev = dc_init(1, ibaund);
	}
	else if (str == "com3")
	{
		icdev = dc_init(2, ibaund);
	}
	if ((int)icdev <= 0)
	{
		t10DemoDlg->AddEdit(_T("Init Com Error!"));
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("Init Com OK!"));
	}
	dc_beep(icdev, 10);
	//��Ƶ��λ
	dc_reset(icdev, 1);
	//���ÿ���
	st = dc_config_card(icdev, 'A');
	//Ѱ�������ؿ����к�
	st = dc_card_n(icdev, 0, &SnrLen, _Snr);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Ok!"));
		/*for (int i = 0; i < 4; i++)
		{
			_Snr[i] = _Snr[3 - i];
		}*/
		//memset(szSnr, 0x00, sizeof(szSnr));
		//hex_a(_Snr, szSnr, SnrLen);
		t10DemoDlg->AddEdit((LPCSTR)_Snr);
	}
	//��֤������
	st = dc_authentication_passaddr(icdev, 0, 7, (unsigned char *)"\x11\x22\x33\x44\x55\x66");
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_authentication_passaddr Error!"));
		goto safeExit;
		return;
	}
	else
		t10DemoDlg->AddEdit(_T("dc_authentication_passaddr OK!"));
	//��ֵ��ʼ��Ϊ0
	st = dc_initval(icdev, 5, 0);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_initval Error!"));
		goto safeExit;
		return;
	}
	else
		t10DemoDlg->AddEdit(_T("dc_initval OK!"));
	//����ֵ
	st = dc_readval(icdev, 5, &uivalue);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_readval Erro!"));
		goto safeExit;
		return;
	}
	else
	{
		_itoa_s(uivalue, cvalue, 10);
		t10DemoDlg->AddEdit(cvalue);
	}
	//���ֵ
	st = dc_increment(icdev, 5, 1000);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_increment Error!"));
		goto safeExit;
		return;
	}
	else
		t10DemoDlg->AddEdit(_T("dc_increment OK!"));
	//����ֵ
	st = dc_readval(icdev, 5, &uivalue);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_readval Erro!"));
		goto safeExit;
		return;
	}
	else
	{
		_itoa_s(uivalue, cvalue, 10);
		t10DemoDlg->AddEdit(cvalue);
	}
	//���ֵ
	st = dc_decrement(icdev, 5, 100);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_decrement Error!"));
		goto safeExit;
		return;
	}
	else
		t10DemoDlg->AddEdit(_T("dc_decrement OK!"));
	//����ֵ
	st = dc_readval(icdev, 5, &uivalue);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_readval Erro!"));
		goto safeExit;
		return;
	}
	else
	{
		_itoa_s(uivalue, cvalue, 10);
		t10DemoDlg->AddEdit(cvalue);
	}
	//��ֵ����
	st = dc_restore(icdev, 5);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_restore Error!!"));
		goto safeExit;
		return;
	}
	else
		t10DemoDlg->AddEdit(_T("dc_restore OK!"));
	st = dc_transfer(icdev, 6);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_transfer Error!"));
		goto safeExit;
		return;
	}
	else
		t10DemoDlg->AddEdit(_T("dc_transfer OK!"));
	//����ֵ
	st = dc_readval(icdev, 6, &uivalue);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_readval Erro!"));
		goto safeExit;
		return;
	}
	else
	{
		_itoa_s(uivalue, cvalue, 10);
		t10DemoDlg->AddEdit(cvalue);
	}
safeExit:
	if ((int)icdev > 0)
	{
		st = dc_exit(icdev);
		if (st != 0)
		{
			t10DemoDlg->AddEdit(_T("dc_exit Error!"));
			goto safeExit;
			return;
		}
		else
		{
			t10DemoDlg->AddEdit(_T("dc_exit OK!"));
			icdev = (HANDLE)-1;
		}
	}
}