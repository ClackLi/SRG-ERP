#include "stdafx.h"
#include "CPUTypeA.h"

void CPUTypeA()
{
	HANDLE icdev = (HANDLE)-1;
	int st = -1;
	unsigned char _Snr[100] = "\0";
	unsigned char szSnr[100] = "\0";
	unsigned int SnrLen = 0;
	CString str = _T("");
	int ibaund = 0;
	HWND hWnd = ::FindWindow(NULL, _T("T10demo"));
	CWnd* pWnd = AfxGetApp()->GetMainWnd();
	CdemoDlg *t10DemoDlg = (CdemoDlg*)CWnd::FromHandle(hWnd);

	pWnd->GetDlgItemText(IDC_COMBO1, str);
	ibaund = pWnd->GetDlgItemInt(IDC_COMBO2);
	if (str == "usb")
		icdev = dc_init(100, ibaund);
	else if (str == "PSCS")
	{
		icdev = dc_init(200, ibaund);
	}
	else if (str == "com1")
	{
		icdev = dc_init(0, ibaund);
	}
	else if (str == "com2")
	{
		icdev = dc_init(1, ibaund);
	}
	else if (str == "com3")
	{
		icdev = dc_init(2, ibaund);
	}
	if ((int)icdev <= 0)
	{
		t10DemoDlg->AddEdit(_T("Init Com Error!"));
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("Init Com OK!"));
	}
	dc_beep(icdev, 10);
	//��Ƶ��λ
	dc_reset(icdev, 1);
	st = dc_config_card(icdev, 'A');
	st = dc_card_n(icdev, 0, &SnrLen, _Snr);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_card_n Ok!"));
		memset(szSnr, 0x00, sizeof(szSnr));
		hex_a(_Snr, szSnr, SnrLen);
		t10DemoDlg->AddEdit((LPCSTR)szSnr);
	}
	unsigned char rcardlen = 0;
	unsigned int rlen = 0;
	unsigned char databuffer[100] = "\0";
	unsigned char databufferhex[100] = "\0";
	st = dc_pro_resetInt(icdev, &rcardlen, databuffer);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_pro_resetInt Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_pro_resetInt Ok!"));
		hex_a(databuffer, databufferhex, (short)rcardlen);
		t10DemoDlg->AddEdit((LPCSTR)databufferhex);
	}
	st = dc_pro_commandlinkInt(icdev, 5, (unsigned char*)"\x00\x84\x00\x00\x08", &rlen, databuffer, 10);
	if (st != 0)
	{
		t10DemoDlg->AddEdit(_T("dc_pro_commandlinkInt Error!"));
		goto safeExit;
		return;
	}
	else
	{
		t10DemoDlg->AddEdit(_T("dc_pro_commandlinkInt Ok!"));
		hex_a(databuffer, databufferhex, rlen);
		t10DemoDlg->AddEdit((LPCSTR)databufferhex);
	}
	
safeExit:
	if ((int)icdev > 0)
	{
		st = dc_exit(icdev);
		if (st != 0)
		{
			t10DemoDlg->AddEdit(_T("dc_exit Error!"));
			return;
		}
		else
		{
			t10DemoDlg->AddEdit(_T("dc_exit OK!"));
			icdev = (HANDLE)-1;
		}
	}
	return;
}