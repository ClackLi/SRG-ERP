// idfgcheckDlg.cpp : implementation file
//

#include "stdafx.h"
#include "idfgcheck.h"
#include "idfgcheckDlg.h"
#include "dcrf32.h"
#pragma comment(lib, "dcrf32.lib")

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIdfgcheckDlg dialog

CIdfgcheckDlg::CIdfgcheckDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIdfgcheckDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIdfgcheckDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CIdfgcheckDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIdfgcheckDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIdfgcheckDlg, CDialog)
	//{{AFX_MSG_MAP(CIdfgcheckDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIdfgcheckDlg message handlers

BOOL CIdfgcheckDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
  photo_hbitmap_ = NULL;
  fingerprint_hbitmap_ = NULL;
  run_flag_ = false;
  enter_flag_ = false;

  // SetTimer(1, 50, NULL);
	
  GetDlgItem(IDC_BUTTON1)->SetFocus();
	return FALSE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CIdfgcheckDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CIdfgcheckDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CIdfgcheckDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	// CDialog::OnOK();
}

void CIdfgcheckDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	KillTimer(1);
	CDialog::OnCancel();
}

void CIdfgcheckDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
  int port = 100, baud = 115200;
  int result;
  HANDLE handle;
  unsigned char buffer[2048];
  CString str;

  if (run_flag_) {
    SetDlgItemText(IDC_BUTTON1, "��ȡ����֤��Ϣ");
    run_flag_ = !run_flag_;
    return;
  }

  InfoPrint("", false);

  photo_hbitmap_ = NULL;
  GetDlgItem(IDC_STATIC_PHOTO)->Invalidate(TRUE);
  GetDlgItem(IDC_STATIC_PHOTO)->UpdateWindow();

  fingerprint_hbitmap_ = NULL;
  GetDlgItem(IDC_STATIC_FINGERPRINT)->Invalidate(TRUE);
  GetDlgItem(IDC_STATIC_FINGERPRINT)->UpdateWindow();

  StatusPrint("");

  result = (int)dc_init(port, baud);
  if (result < 0) {
    StatusPrint("�豸��ʼ��ʧ��!");
    return;
  }

  handle = (HANDLE)result;

  result = dc_getver(handle, buffer);
  if (result != 0) {
    StatusPrint("�豸ͨѶ�쳣!");
    dc_exit(handle);
    return;
  }

  InfoPrint("================================================================\r\n", true);
  str.Format("�豸�汾��: %s\r\n", (char *)buffer);
  InfoPrint(str, true);
  InfoPrint("================================================================\r\n", true);

  result = ReadIdCard(handle);
  if (result != 0) {
    StatusPrint("��ȡ����֤ʧ��!");
    dc_exit(handle);
    return;
  }

  dc_beep(handle, 20);
  dc_exit(handle);
/*
  if (fingerprint_len_ > 0) {
    result = zzGetDeviceVersion(0, (char *)buffer);
    if (result != 0) {
      StatusPrint("ָ��ģ���쳣!");
      return;
    }

    InfoPrint("================================================================\r\n", true);
    str.Format("ָ��ģ��汾��: %s\r\n", (char *)buffer);
    InfoPrint(str, true);
    InfoPrint("================================================================\r\n", true);

    SetDlgItemText(IDC_BUTTON1, "ֹͣ�ɼ�");
    run_flag_ = true;

    return;
  }
*/
  StatusPrint("�ɹ�!");
}

void CIdfgcheckDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if (run_flag_ & !enter_flag_)
  {
    enter_flag_ = true;
    // CheckFingerprint();
    enter_flag_ = false;
  }

	CDialog::OnTimer(nIDEvent);
}

HBRUSH CIdfgcheckDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

  if (pWnd->GetDlgCtrlID() == IDC_STATIC_PHOTO)
  {
    CRect rect;
    GetDlgItem(IDC_STATIC_PHOTO)->GetClientRect(&rect);
    if (photo_hbitmap_ != NULL)
    {
      CDC memory_dc;
      BITMAP bitmap;
      memory_dc.CreateCompatibleDC(pDC);
      memory_dc.SelectObject(photo_hbitmap_);
      GetObject(photo_hbitmap_, sizeof(bitmap), &bitmap);
      pDC->StretchBlt(0, 0, rect.Width(), rect.Height(), &memory_dc, 0, 0, bitmap.bmWidth, bitmap.bmHeight, SRCCOPY);
    }
    else
    {
      pDC->FillRect(rect, CBrush::FromHandle((HBRUSH)GetStockObject(BLACK_BRUSH)));
    }
    return NULL;
  }
  
  if (pWnd->GetDlgCtrlID() == IDC_STATIC_FINGERPRINT)
  {
    CRect rect;
    GetDlgItem(IDC_STATIC_FINGERPRINT)->GetClientRect(&rect);
    if (fingerprint_hbitmap_ != NULL)
    {
      DisplayFingerPrint(pDC, fingerprint_data_, 256, 360);
    }
    else
    {
      pDC->FillRect(rect, CBrush::FromHandle((HBRUSH)GetStockObject(BLACK_BRUSH)));
    }
    return NULL;
  }

  return hbr;
}

void CIdfgcheckDlg::InfoPrint(const char *str, bool is_added) {
  if (is_added) {
    int i = ((CEdit *)GetDlgItem(IDC_EDIT1))->GetWindowTextLength();
    ((CEdit *)GetDlgItem(IDC_EDIT1))->SetSel(i, i);
    ((CEdit *)GetDlgItem(IDC_EDIT1))->ReplaceSel(str);
  } else {
    SetDlgItemText(IDC_EDIT1, str);
  }
  
  ((CEdit *)GetDlgItem(IDC_EDIT1))->LineScroll(((CEdit *)GetDlgItem(IDC_EDIT1))->GetLineCount());
  
  GetDlgItem(IDC_EDIT1)->Invalidate();
  GetDlgItem(IDC_EDIT1)->UpdateWindow();
}

void CIdfgcheckDlg::StatusPrint(const char *str) {
  SetDlgItemText(IDC_EDIT2, str);
  GetDlgItem(IDC_EDIT2)->Invalidate();
  GetDlgItem(IDC_EDIT2)->UpdateWindow();
}

int CIdfgcheckDlg::ReadIdCard(HANDLE handle) {
  int result;
  unsigned char info_buffer[64];
  int text_len;
  unsigned char text[256];
  int photo_len;
  unsigned char photo[1024];
  int extra_len;
  unsigned char extra[70];
  int type = 0;
/*
  result = dc_get_idsnr_hex(handle, (char *)info_buffer);
  if (result != 0) {
    return -1;
  }
  InfoPrint("��Ƭ���к�: ", true); InfoPrint((char *)info_buffer, true); InfoPrint("\r\n\r\n", true);
*/
  result = dc_SamAReadCardInfo(handle, 3, &text_len, text, &photo_len, photo, &fingerprint_len_, fingerprint_, &extra_len, extra);
  if (result != 0) {
    return -1;
  }

  switch (text[248]) {
  case 'I':
    type = 1;
    break;
  case 'J':
    type = 2;
    break;
  }

  if (type == 0) {
    unsigned char name[64];
    unsigned char sex[8];
    unsigned char nation[12];
    unsigned char birth_day[36];
    unsigned char address[144];
    unsigned char id_number[76];
    unsigned char department[64];
    unsigned char expire_start_day[36];
    unsigned char expire_end_day[36];
    unsigned char reserved[76];

    result = dc_ParseTextInfo(handle, 0, text_len, text, name, sex, nation, birth_day, address, id_number, department, expire_start_day, expire_end_day, reserved);
    if (result != 0) {
      return -1;
    }
    InfoPrint("����: ", true); InfoPrint((char *)name, true); InfoPrint("\r\n", true);
    dc_ParseOtherInfo(handle, 0, sex, info_buffer);
    InfoPrint("�Ա�: ", true); InfoPrint((char *)info_buffer, true); InfoPrint("\r\n", true);
    dc_ParseOtherInfo(handle, 1, nation, info_buffer);
    InfoPrint("����: ", true); InfoPrint((char *)info_buffer, true); InfoPrint("\r\n", true);
    InfoPrint("��������: ", true); InfoPrint((char *)birth_day, true); InfoPrint("\r\n", true);
    InfoPrint("סַ: ", true); InfoPrint((char *)address, true); InfoPrint("\r\n", true);
    InfoPrint("�������ݺ���: ", true); InfoPrint((char *)id_number, true); InfoPrint("\r\n", true);
    InfoPrint("ǩ������: ", true); InfoPrint((char *)department, true); InfoPrint("\r\n", true);
    InfoPrint("֤��ǩ������: ", true); InfoPrint((char *)expire_start_day, true); InfoPrint("\r\n", true);
    InfoPrint("֤����ֹ����: ", true); InfoPrint((char *)expire_end_day, true); InfoPrint("\r\n", true);
  } else if (type == 1) {
    unsigned char english_name[244];
    unsigned char sex[8];
    unsigned char id_number[64];
    unsigned char citizenship[16];
    unsigned char chinese_name[64];
    unsigned char expire_start_day[36];
    unsigned char expire_end_day[36];
    unsigned char birth_day[36];
    unsigned char version_number[12];
    unsigned char department_code[20];
    unsigned char type_sign[8];
    unsigned char reserved[16];

    result = dc_ParseTextInfoForForeigner(handle, 0, text_len, text, english_name, sex, id_number, citizenship, chinese_name, expire_start_day, expire_end_day, birth_day, version_number, department_code, type_sign, reserved);
    if (result != 0) {
      return -1;
    }
    InfoPrint("Ӣ������: ", true); InfoPrint((char *)english_name, true); InfoPrint("\r\n", true);
    InfoPrint("�Ա�: ", true); InfoPrint(((strcmp((char *)sex, "1") == 0) ? "M" : "F"), true); InfoPrint("\r\n", true);
    InfoPrint("���þ���֤����: ", true); InfoPrint((char *)id_number, true); InfoPrint("\r\n", true);
    dc_ParseOtherInfo(handle, 2, citizenship, info_buffer);
    InfoPrint("���������ڵ�������: ", true); InfoPrint((char *)info_buffer, true); InfoPrint("\r\n", true);
    InfoPrint("��������: ", true); InfoPrint((char *)chinese_name, true); InfoPrint("\r\n", true);
    InfoPrint("֤��ǩ������: ", true); InfoPrint((char *)expire_start_day, true); InfoPrint("\r\n", true);
    InfoPrint("֤����ֹ����: ", true); InfoPrint((char *)expire_end_day, true); InfoPrint("\r\n", true);
    InfoPrint("��������: ", true); InfoPrint((char *)birth_day, true); InfoPrint("\r\n", true);
    InfoPrint("֤���汾��: ", true); InfoPrint((char *)version_number, true); InfoPrint("\r\n", true);
    InfoPrint("���������������ش���: ", true); InfoPrint((char *)department_code, true); InfoPrint("\r\n", true);
    InfoPrint("֤�����ͱ�ʶ: ", true); InfoPrint((char *)type_sign, true); InfoPrint("\r\n", true);
  } else if (type == 2) {
    unsigned char name[64];
    unsigned char sex[8];
    unsigned char reserved[12];
    unsigned char birth_day[36];
    unsigned char address[144];
    unsigned char id_number[76];
    unsigned char department[64];
    unsigned char expire_start_day[36];
    unsigned char expire_end_day[36];
    unsigned char pass_number[40];
    unsigned char sign_count[12];
    unsigned char reserved2[16];
    unsigned char type_sign[8];
    unsigned char reserved3[16];

    result = dc_ParseTextInfoForHkMoTw(handle, 0, text_len, text, name, sex, reserved, birth_day, address, id_number, department, expire_start_day, expire_end_day, pass_number, sign_count, reserved2, type_sign, reserved3);
    if (result != 0) {
      return -1;
    }
    InfoPrint("����: ", true); InfoPrint((char *)name, true); InfoPrint("\r\n", true);
    dc_ParseOtherInfo(handle, 0, sex, info_buffer);
    InfoPrint("�Ա�: ", true); InfoPrint((char *)info_buffer, true); InfoPrint("\r\n", true);
    InfoPrint("��������: ", true); InfoPrint((char *)birth_day, true); InfoPrint("\r\n", true);
    InfoPrint("סַ: ", true); InfoPrint((char *)address, true); InfoPrint("\r\n", true);
    InfoPrint("�������ݺ���: ", true); InfoPrint((char *)id_number, true); InfoPrint("\r\n", true);
    InfoPrint("ǩ������: ", true); InfoPrint((char *)department, true); InfoPrint("\r\n", true);
    InfoPrint("֤��ǩ������: ", true); InfoPrint((char *)expire_start_day, true); InfoPrint("\r\n", true);
    InfoPrint("֤����ֹ����: ", true); InfoPrint((char *)expire_end_day, true); InfoPrint("\r\n", true);
    InfoPrint("ͨ��֤����: ", true); InfoPrint((char *)pass_number, true); InfoPrint("\r\n", true);
    InfoPrint("ǩ������: ", true); InfoPrint((char *)sign_count, true); InfoPrint("\r\n", true);
    InfoPrint("֤�����ͱ�ʶ: ", true); InfoPrint((char *)type_sign, true); InfoPrint("\r\n", true);
  }

  result = dc_ParsePhotoInfo(handle, 0, photo_len, photo, 0, (unsigned char *)"me.bmp");
  if (result != 0) {
    return -1;
  }

  InfoPrint("\r\n", true);

  photo_hbitmap_ = (HBITMAP)LoadImage(AfxGetInstanceHandle(), "me.bmp", IMAGE_BITMAP, 0, 0, LR_DEFAULTSIZE | LR_LOADFROMFILE);
  DeleteFile("me.bmp");
  GetDlgItem(IDC_STATIC_PHOTO)->Invalidate(TRUE);
  GetDlgItem(IDC_STATIC_PHOTO)->UpdateWindow();

  return 0;
}
/*
void CIdfgcheckDlg::CheckFingerprint() {
  int result;
  unsigned char buffer[2048];
  CString str;

  StatusPrint("�ɼ�ָ��ͼ���밴��ָ ... ");

  result = zzExtractFingerprint(0, 10000, buffer, 50, 0);

  if (zzCaptureFingerprint(0, fingerprint_data_, 1000, 0) == 0) {
    fingerprint_hbitmap_ = (HBITMAP)1;
    GetDlgItem(IDC_STATIC_FINGERPRINT)->Invalidate(TRUE);
    GetDlgItem(IDC_STATIC_FINGERPRINT)->UpdateWindow();
  }

  if (result != 0) {
    return;
  }

  fingerprint_hbitmap_ = (HBITMAP)1;
  GetDlgItem(IDC_STATIC_FINGERPRINT)->Invalidate(TRUE);
  GetDlgItem(IDC_STATIC_FINGERPRINT)->UpdateWindow();

  if (zzMatchFingerprint(fingerprint_, buffer, 3) != 0) {
    StatusPrint("ƥ��ʧ�ܣ�");
    InfoPrint("ƥ������ʧ��\r\n", true);
    OnButton1();
    return;
  }

  InfoPrint("ƥ�������ɹ�\r\n", true);

  StatusPrint("�ɹ�!");

  OnButton1();
}
*/
void CIdfgcheckDlg::DisplayFingerPrint(CDC *pDC, unsigned char *lpImgData, int iWidth, int iHeight)
{
  unsigned char *showImage;
  BYTE bmpHdr[1500];
  BITMAPINFO* pBmpInfo = (BITMAPINFO*)bmpHdr;
  pBmpInfo->bmiHeader.biSize   = sizeof(BITMAPINFOHEADER);
  pBmpInfo->bmiHeader.biWidth  = iWidth;
  pBmpInfo->bmiHeader.biHeight = iHeight;
  pBmpInfo->bmiHeader.biPlanes = 1;
  pBmpInfo->bmiHeader.biBitCount = 8;
  pBmpInfo->bmiHeader.biCompression = 0;
  pBmpInfo->bmiHeader.biSizeImage   = iWidth*iHeight;
  pBmpInfo->bmiHeader.biXPelsPerMeter = 0;
  pBmpInfo->bmiHeader.biYPelsPerMeter = 0;
  pBmpInfo->bmiHeader.biClrUsed = 0;
  pBmpInfo->bmiHeader.biClrImportant  = 0;
  
  for (int i=0; i<256; i++)
  {
    pBmpInfo->bmiColors[i].rgbRed = i;
    pBmpInfo->bmiColors[i].rgbGreen = i;
    pBmpInfo->bmiColors[i].rgbBlue = i;
    pBmpInfo->bmiColors[i].rgbReserved = 0;
  }
  
  showImage = (unsigned char*)malloc(iWidth*iHeight);
  //���·�ת
  for(int j=0;j<iHeight/2;j++)
  {
    memcpy(showImage+j*iWidth,lpImgData+(iHeight-1-j)*iWidth,iWidth);
    memcpy(showImage+(iHeight-1-j)*iWidth,lpImgData+j*iWidth,iWidth);
  }
  
  StretchDIBits(pDC->GetSafeHdc(), 0, 0, iWidth, iHeight, 0, 0, iWidth, iHeight, showImage, pBmpInfo, DIB_RGB_COLORS, SRCCOPY);
  free(showImage);
}
