// idfgcheckDlg.h : header file
//

#if !defined(AFX_IDFGCHECKDLG_H__9D7967B4_F812_46A6_A6CF_F23820D2BFDF__INCLUDED_)
#define AFX_IDFGCHECKDLG_H__9D7967B4_F812_46A6_A6CF_F23820D2BFDF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CIdfgcheckDlg dialog

class CIdfgcheckDlg : public CDialog
{
// Construction
public:
	CIdfgcheckDlg(CWnd* pParent = NULL);	// standard constructor
  void InfoPrint(const char *str, bool is_added);
  void StatusPrint(const char *str);
  int ReadIdCard(HANDLE handle);
  void CheckFingerprint();
  void DisplayFingerPrint(CDC *pDC, unsigned char *lpImgData, int iWidth, int iHeight);
  HBITMAP photo_hbitmap_, fingerprint_hbitmap_;
  int fingerprint_len_;
  unsigned char fingerprint_[1024];
  bool run_flag_;
  bool enter_flag_;
  unsigned char fingerprint_data_[256 * 360];

// Dialog Data
	//{{AFX_DATA(CIdfgcheckDlg)
	enum { IDD = IDD_IDFGCHECK_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIdfgcheckDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CIdfgcheckDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnButton1();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IDFGCHECKDLG_H__9D7967B4_F812_46A6_A6CF_F23820D2BFDF__INCLUDED_)
