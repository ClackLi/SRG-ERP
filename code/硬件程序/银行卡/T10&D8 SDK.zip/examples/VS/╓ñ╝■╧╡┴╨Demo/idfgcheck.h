// idfgcheck.h : main header file for the IDFGCHECK application
//

#if !defined(AFX_IDFGCHECK_H__A8FDC0ED_233D_4B1F_A1AA_36BE310B9F47__INCLUDED_)
#define AFX_IDFGCHECK_H__A8FDC0ED_233D_4B1F_A1AA_36BE310B9F47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CIdfgcheckApp:
// See idfgcheck.cpp for the implementation of this class
//

class CIdfgcheckApp : public CWinApp
{
public:
	CIdfgcheckApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIdfgcheckApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CIdfgcheckApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IDFGCHECK_H__A8FDC0ED_233D_4B1F_A1AA_36BE310B9F47__INCLUDED_)
