# -*- coding: utf-8 -*-


from TypeCastSimple import *

class MifareDesFire():

    def __init__(self,dev,dll,info_print):
        self.dev = dev
        self.dll = dll
        self.info_print = info_print
        self.rbuff = TypeFactory("UCHAR *", 128)
        self.rlen = TypeFactory("UCHAR *", 64)


    def MyAHex(self,str):
        return binascii.a2b_hex(str.replace(' ', ''))

    def MyHexA(self,str):
        return binascii.b2a_hex(str).upper()

    def run(self):
        self.dll.dc_beep(self.dev,10)

        #//射频复位
        self.dll.dc_reset(self.dev, 1)

        #设置卡类型
        self.dll.dc_config_card(self.dev,'A')

        # 寻卡并返回卡序列号
        res = self.dll.dc_card_n(self.dev, 0, self.rlen, self.rbuff)
        if res != 0:
            self.info_print.append('dc_card_n_Error!')
            return
        else:
            self.info_print.append('dc_card_n OK!')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())
            # print(self.MyHexA(self.rbuff.value).decode())

        #非接触式CPU卡复位
        res=self.dll.dc_pro_resetInt(self.dev,self.rlen,self.rbuff)
        if res !=0:
            self.info_print.append('dc_pro_resetInt Error!')
            return
        else:
            self.info_print.append('dc_pro_resetInt OK!\n')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())

        #非接触式CPU卡指令交互。
        res=self.dll.dc_pro_commandlinkInt_hex(self.dev,5,'0084000008'.encode(),self.rlen,self.rbuff,10)
        if res !=0:
            self.info_print.append('dc_pro_commandlinkInt_hex Error!')
            return
        else:
            self.info_print.append('dc_pro_commandlinkInt_hex OK!')
            self.info_print.append(self.rbuff.value.decode())
            # self.info_print.append(self.MyHexA(self.rbuff.value).decode())






    def info_print_func(self):
        self.info_print.show()
