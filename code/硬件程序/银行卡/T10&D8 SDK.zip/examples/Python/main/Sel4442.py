# -*- coding: utf-8 -*-

from TypeCastSimple import *
import random

class Sel4442():

    def __init__(self,dev,dll,info_print):
        self.dev = dev
        self.dll = dll
        self.info_print = info_print
        self.rbuff = TypeFactory("UCHAR *", 128)
        self.rlen = TypeFactory("UCHAR *", 64)
        self.write_data=''


    def MyAHex(self,str):
        return binascii.a2b_hex(str.replace(' ', ''))

    def MyHexA(self,str):
        return binascii.b2a_hex(str).upper()



    def run(self):
        #蜂鸣
        self.dll.dc_beep(self.dev,10)
        #射频复位
        self.dll.dc_verifypin_4442_hex(self.dev,'FFFFFF'.encode())
        for  i in range(50):
            self.write_data+= str(random.randint(1,9))

        #写数据
        res=self.dll.dc_write_4442_hex(self.dev,32,50,self.write_data.encode())
        if res !=0:
            self.info_print.append('dc_write_4442_hex Error!')
            return
        else:
            self.info_print.append('dc_write_4442_hex OK!')

        #读数据
        res=self.dll.dc_read_4442(self.dev,32,50,self.rbuff)
        if res !=0 :
            self.info_print.append('dc_read_4442 Error!')
            return
        else:
            self.info_print.append('dc_read_4442 OK!')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())



    def info_print_func(self):
        self.info_print.show()