# -*- coding: utf-8 -*-

from TypeCastSimple import *
import random

class CPU():

    def __init__(self,dev,dll,info_print):
        self.dev = dev
        self.dll = dll
        self.info_print = info_print
        self.rbuff = TypeFactory("UCHAR *", 256)
        self.rlen = TypeFactory("UCHAR *", 64)
        self.write_data=''


    def MyAHex(self,str):
        return binascii.a2b_hex(str.replace(' ', ''))

    def MyHexA(self,str):
        return binascii.b2a_hex(str).upper()



    def run(self):
        #蜂鸣
        self.dll.dc_beep(self.dev,10)

        res=self.dll.dc_setcpu(self.dev,0x0D)
        if res !=0:
            self.info_print.append('dc_setcpu Error!')
            return

        res=self.dll.dc_cpureset(self.dev,self.rlen,self.rbuff)
        if res !=0:
            self.info_print.append('dc_cpureset Error!')
            return
        else:
            self.info_print.append('dc_cpureset OK!')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())

        res=self.dll.dc_cpuapduInt_hex(self.dev,5,'0084000008'.encode(),self.rlen,self.rbuff)
        if res !=0:
            self.info_print.append('dc_cpuapduInt_hex Error!')
            return
        else:
            self.info_print.append('dc_cpuapduInt_hex OK!')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())





    def info_print_func(self):
        self.info_print.show()