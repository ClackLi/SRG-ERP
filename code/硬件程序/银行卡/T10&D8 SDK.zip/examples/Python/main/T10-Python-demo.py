# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'T10-Python-demo.ui'
#
# Created by: PyQt5 UI code generator 5.5.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMainWindow,QMessageBox,QApplication
import sys
import os
from ctypes import  *


from main.M1WriteRead import M1WriteRead
from main.M1_Value import M1_Value
from main.CPUTypeA import CPUTypeA
from main.CPUTypeB import CPUTypeB
from main.MifareDesFire import MifareDesFire
from main.MiFarePlus import MiFarePlus
from main.ULtralight import ULtralight
from main.ULtralight_C import ULtralight_C
from main.Sel4442 import Sel4442
from main.Sel4428 import Sel4428
from main._24CXX import _24CXX
from main.CPU import CPU
from main.ID import ID



class Ui_MainWindow(QMainWindow):

    def setupUi(self):
        self.setObjectName("MainWindow")
        self.resize(1032, 605)
        self.setMaximumSize(QtCore.QSize(1032, 605))
        self.setMinimumSize(QtCore.QSize(1032, 605))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.setFont(font)
        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")
        self.conn_type = QtWidgets.QComboBox(self.centralwidget)
        self.conn_type.setGeometry(QtCore.QRect(90, 10, 91, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.conn_type.setFont(font)
        self.conn_type.setObjectName("conn_type")
        self.conn_type.addItem("")
        self.conn_type.addItem("")
        self.conn_type.addItem("")
        self.conn_type.addItem("")
        self.conn_type.addItem("")
        self.conn_type.addItem("")
        self.conn_type.addItem("")
        self.conn_type.addItem("")
        self.conn_type.addItem("")
        self.conn_type.addItem("")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 20, 54, 12))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(210, 20, 91, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.baud = QtWidgets.QComboBox(self.centralwidget)
        self.baud.setGeometry(QtCore.QRect(310, 10, 91, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.baud.setFont(font)
        self.baud.setObjectName("baud")
        self.baud.addItem("")
        self.baud.addItem("")
        self.baud.addItem("")
        self.baud.setEnabled(False)
        font.setBold(False)
        font.setPointSize(10)
        self.info_print = QtWidgets.QTextBrowser(self.centralwidget)
        self.info_print.setGeometry(QtCore.QRect(500, 10, 521, 581))
        self.info_print.setObjectName("info_print")
        self.info_print.setFont(font)
        self.horizontalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(10, 80, 471, 61))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setSpacing(10)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.M1WriteRead_button = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.M1WriteRead_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.M1WriteRead_button.setFont(font)
        self.M1WriteRead_button.setObjectName("M1WriteRead_button")
        self.horizontalLayout.addWidget(self.M1WriteRead_button)
        self.M1Value_button = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.M1Value_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.M1Value_button.setFont(font)
        self.M1Value_button.setObjectName("M1Value_button")
        self.horizontalLayout.addWidget(self.M1Value_button)
        self.CPUTypeA_button = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.CPUTypeA_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.CPUTypeA_button.setFont(font)
        self.CPUTypeA_button.setObjectName("CPUTypeA_button")
        self.horizontalLayout.addWidget(self.CPUTypeA_button)
        self.CPUTypeB_button = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.CPUTypeB_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.CPUTypeB_button.setFont(font)
        self.CPUTypeB_button.setObjectName("CPUTypeB_button")
        self.horizontalLayout.addWidget(self.CPUTypeB_button)
        self.horizontalLayoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget_2.setGeometry(QtCore.QRect(10, 160, 471, 61))
        self.horizontalLayoutWidget_2.setObjectName("horizontalLayoutWidget_2")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setSpacing(10)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.MifareDESFire_button = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.MifareDESFire_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.MifareDESFire_button.setFont(font)
        self.MifareDESFire_button.setObjectName("MifareDESFire_button")
        self.horizontalLayout_2.addWidget(self.MifareDESFire_button)
        self.MifarePlus_button = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.MifarePlus_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.MifarePlus_button.setFont(font)
        self.MifarePlus_button.setObjectName("MifarePlus_button")
        self.horizontalLayout_2.addWidget(self.MifarePlus_button)
        self.ULtralight_button = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.ULtralight_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.ULtralight_button.setFont(font)
        self.ULtralight_button.setObjectName("ULtralight_button")
        self.horizontalLayout_2.addWidget(self.ULtralight_button)
        self.ULtralightC_button = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.ULtralightC_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.ULtralightC_button.setFont(font)
        self.ULtralightC_button.setObjectName("ULtralightC_button")
        self.horizontalLayout_2.addWidget(self.ULtralightC_button)
        self.horizontalLayoutWidget_3 = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget_3.setGeometry(QtCore.QRect(10, 240, 471, 61))
        self.horizontalLayoutWidget_3.setObjectName("horizontalLayoutWidget_3")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_3)
        self.horizontalLayout_3.setSpacing(10)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.card_4442_button = QtWidgets.QPushButton(self.horizontalLayoutWidget_3)
        self.card_4442_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.card_4442_button.setFont(font)
        self.card_4442_button.setObjectName("card_4442_button")
        self.horizontalLayout_3.addWidget(self.card_4442_button)
        self.card_4428_button_button = QtWidgets.QPushButton(self.horizontalLayoutWidget_3)
        self.card_4428_button_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.card_4428_button_button.setFont(font)
        self.card_4428_button_button.setObjectName("card_4428_button_button")
        self.horizontalLayout_3.addWidget(self.card_4428_button_button)
        self.card_24CXX_button = QtWidgets.QPushButton(self.horizontalLayoutWidget_3)
        self.card_24CXX_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.card_24CXX_button.setFont(font)
        self.card_24CXX_button.setObjectName("card_24CXX_button")
        self.horizontalLayout_3.addWidget(self.card_24CXX_button)
        self.card_CPU_button = QtWidgets.QPushButton(self.horizontalLayoutWidget_3)
        self.card_CPU_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.card_CPU_button.setFont(font)
        self.card_CPU_button.setObjectName("card_CPU_button")
        self.horizontalLayout_3.addWidget(self.card_CPU_button)
        self.card_ID_button = QtWidgets.QPushButton(self.centralwidget)
        self.card_ID_button.setGeometry(QtCore.QRect(10, 340, 110, 30))
        self.card_ID_button.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.card_ID_button.setFont(font)
        self.card_ID_button.setObjectName("card_ID_button")
        self.ID_Image = QtWidgets.QGraphicsView(self.centralwidget)
        self.ID_Image.setGeometry(QtCore.QRect(260, 340, 201, 231))
        self.ID_Image.setObjectName("ID_Image")
        self.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(self)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1032, 23))
        self.menubar.setObjectName("menubar")
        self.setMenuBar(self.menubar)

        self.retranslateUi(self)
        QtCore.QMetaObject.connectSlotsByName(self)

        # --init_dll
        self.dll = WinDLL(os.path.join(os.getcwd(), "dcrf32.dll"))

        # -------event_bound
        self.conn_type.currentIndexChanged.connect(self.is_baud_rate_Enable)
        self.M1WriteRead_button.clicked.connect(self.M1WriteRead_func)
        self.M1Value_button.clicked.connect(self.M1_Value_func)
        self.CPUTypeA_button.clicked.connect(self.CPUTypeA_func)
        self.CPUTypeB_button.clicked.connect(self.CPUTypeB_func)
        self.MifareDESFire_button.clicked.connect(self.MifareDesFire_func)
        self.MifarePlus_button.clicked.connect(self.MiFarePlus_func)
        self.ULtralight_button.clicked.connect(self.ULtralight_func)
        self.ULtralightC_button.clicked.connect(self.ULtralight_C_func)
        self.card_4442_button.clicked.connect(self.Sel4442_func)
        self.card_4428_button_button.clicked.connect(self.Sel4428_func)
        self.card_24CXX_button.clicked.connect(self._24CXX_func)
        self.card_CPU_button.clicked.connect(self.CPU_Func)
        self.card_ID_button.clicked.connect(self.ID_func)



    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "T10demo"))
        self.conn_type.setItemText(0, _translate("MainWindow", "usb"))
        self.conn_type.setItemText(1, _translate("MainWindow", "com1"))
        self.conn_type.setItemText(2, _translate("MainWindow", "com2"))
        self.conn_type.setItemText(3, _translate("MainWindow", "com3"))
        self.conn_type.setItemText(4, _translate("MainWindow", "com4"))
        self.conn_type.setItemText(5, _translate("MainWindow", "com5"))
        self.conn_type.setItemText(6, _translate("MainWindow", "com6"))
        self.conn_type.setItemText(7, _translate("MainWindow", "com7"))
        self.conn_type.setItemText(8, _translate("MainWindow", "com8"))
        self.conn_type.setItemText(9, _translate("MainWindow", "com9"))
        self.label.setText(_translate("MainWindow", "Port:"))
        self.label_2.setText(_translate("MainWindow", "BaudRate:"))
        self.baud.setItemText(0, _translate("MainWindow", "9600"))
        self.baud.setItemText(1, _translate("MainWindow", "115200"))
        self.baud.setItemText(2, _translate("MainWindow", "38400"))
        self.M1WriteRead_button.setText(_translate("MainWindow", "M1WriteRead"))
        self.M1Value_button.setText(_translate("MainWindow", "M1Value"))
        self.CPUTypeA_button.setText(_translate("MainWindow", "CPU-TypeA"))
        self.CPUTypeB_button.setText(_translate("MainWindow", "CPU-TypeB"))
        self.MifareDESFire_button.setText(_translate("MainWindow", "MifareDESFire"))
        self.MifarePlus_button.setText(_translate("MainWindow", "MifarePlus"))
        self.ULtralight_button.setText(_translate("MainWindow", "ULtralight"))
        self.ULtralightC_button.setText(_translate("MainWindow", "ULtralight C"))
        self.card_4442_button.setText(_translate("MainWindow", "4442"))
        self.card_4428_button_button.setText(_translate("MainWindow", "4428"))
        self.card_24CXX_button.setText(_translate("MainWindow", "24CXX"))
        self.card_CPU_button.setText(_translate("MainWindow", "CPU"))
        self.card_ID_button.setText(_translate("MainWindow", "ID"))

    def is_baud_rate_Enable(self):
        self.baud.setEnabled(False) if self.conn_type.currentIndex() == 0 else self.baud.setEnabled(True)

    def connect_device(self):
        self.info_print.append('\n--------------------------------------------------\n')
        if self.conn_type.currentIndex() == 0:
            self.dev = self.dll.dc_init(100, int(self.baud.currentText()))
            if self.dev < 0:
                # QMessageBox.information(self, 'infomation', 'be connected failed')
                self.info_print.append('Init connection Error')
                self.info_print.show()
                return
            self.info_print.append('Init connection OK')
            self.info_print.show()


    def close_conncet(self):
        if self.dev >0:
            res=self.dll.dc_exit(self.dev)
            if res != 0:
                QMessageBox.information(self,  # 使用infomation信息框
                                        "infomation",
                                        "Disconnect failed")
                self.info_print.append('dc_exit Error!')
                return
            else:
                self.info_print.append('dc_exit OK!')

                self.info_print.show()




    def M1WriteRead_func(self):
        self.init_class(M1WriteRead)

    def M1_Value_func(self):
        self.init_class(M1_Value)

    def CPUTypeA_func(self):
        self.init_class(CPUTypeA)

    def CPUTypeB_func(self):
        self.init_class(CPUTypeB)

    def MifareDesFire_func(self):
        self.init_class(MifareDesFire)

    def MiFarePlus_func(self):
        self.init_class(MiFarePlus)

    def ULtralight_func(self):
        self.init_class(ULtralight)

    def ULtralight_C_func(self):
        self.init_class(ULtralight_C)

    def Sel4442_func(self):
        self.init_class(Sel4442)

    def Sel4428_func(self):
        self.init_class(Sel4428)

    def _24CXX_func(self):
        self.init_class(_24CXX)

    def CPU_Func(self):

        self.init_class(CPU)

    def ID_func(self):
        try:
            self.init_class(ID,self.ID_Image)
        except Exception as e:
            print(e)

    def init_class(self,class_object,*args):
        self.connect_device()
        new_class=class_object(self.dev, self.dll, self.info_print,*args)
        new_class.run()
        new_class.info_print_func()
        self.close_conncet()

if __name__=="__main__":
    app=QApplication(sys.argv)
    ui=Ui_MainWindow()
    ui.setupUi()
    ui.show()
    sys.exit(app.exec())