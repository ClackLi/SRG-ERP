# -*- coding: utf-8 -*-


from TypeCastSimple import *

class M1_Value():

    def __init__(self,dev,dll,info_print):
        self.dev = dev
        self.dll = dll
        self.info_print = info_print
        self.rbuff = TypeFactory("UCHAR *", 64)
        self.rlen = TypeFactory("UCHAR *", 64)

        self.data_length=0
        self.data=''


    def MyAHex(self,str):
        return binascii.a2b_hex(str.replace(' ', ''))

    def MyHexA(self,str):
        return binascii.b2a_hex(str).upper()



    def run(self):
        #蜂鸣
        self.dll.dc_beep(self.dev,10)
        #射频复位
        self.dll.dc_reset(self.dev,1)
        #设置卡型
        self.dll.dc_config_card(self.dev,'A')
        #寻卡并返回卡序列号
        res=self.dll.dc_card_n(self.dev,0,self.rlen,self.rbuff)
        if res !=0:
            self.info_print.append('dc_card_n_Error!')
            return
        else:
            self.info_print.append('dc_card_n OK!')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())

        #验证卡密码
        res=self.dll.dc_authentication_passaddr_hex(self.dev,0,7,'FFFFFFFFFFFF'.encode())
        if res !=0:
            self.info_print.append('dc_authentication_passaddr_hex Error!')
            return
        else:
            self.info_print.append('dc_authentication_passaddr_hex OK!')

        # 块值初始化为0
        res = self.dll.dc_initval(self.dev, 5, 0)
        if res != 0:
            self.info_print.append('dc_initval Error!')
            return
        else:
            self.info_print.append('dc_initval OK!')
        # 读块值
        res = self.dll.dc_readval(self.dev, 5,self.rbuff)
        if res != 0:
            self.info_print.append('dc_readval Erro!')
            return
        else:
            if self.rbuff.value==b'':
                self.info_print.append('0')


        #块加值
        res=self.dll.dc_increment(self.dev,5,1000)
        if res !=0:
            self.info_print.append("dc_increment Error!")
            return
        else:
            self.info_print.append("dc_increment OK!")

        #读块值
        res = self.dll.dc_readval(self.dev, 5, self.rbuff)
        if res != 0:
            self.info_print.append('dc_readval Erro!')
            return
        else:
            if self.rbuff.value == b'':
                self.info_print.append('0')
            else:
                self.data_length=len(self.MyHexA(self.rbuff.value).decode())
                self.data=''
                for i in range(int(self.data_length / 2)):
                    self.data += self.MyHexA(self.rbuff.value).decode()[int((self.data_length / 2 - i -1)) * 2:int((self.data_length / 2 - i)) * 2]

                self.info_print.append(str(int(self.data,16)))

        #块减值
        res=self.dll.dc_decrement(self.dev,5,100)
        if res!=0:
            self.info_print.append('dc_decrement Error!')
            return
        else:
            self.info_print.append('dc_decrement OK!')

        #读块值
            res = self.dll.dc_readval(self.dev, 5, self.rbuff)
            if res != 0:
                self.info_print.append('dc_readval Erro!')
                return
            else:
                if self.rbuff.value == b'':
                    self.info_print.append('0')
                else:
                    self.data_length = len(self.MyHexA(self.rbuff.value).decode())
                    self.data = ''
                    for i in range(int(self.data_length / 2)):
                        self.data += self.MyHexA(self.rbuff.value).decode()[
                                     int((self.data_length / 2 - i - 1)) * 2:int((self.data_length / 2 - i)) * 2]

                    self.info_print.append(str(int(self.data, 16)))

        #块值传递
        res=self.dll.dc_restore(self.dev,5)
        if res !=0:
            self.info_print.append('dc_restore Error!')
            return
        else:
            self.info_print.append('dc_restore OK!')

        res=self.dll.dc_transfer(self.dev,6)
        if res !=0:
            self.info_print.append('dc_transfer Error!')
            return
        else:
            self.info_print.append('dc_transfer OK!')


        #读块值
        res = self.dll.dc_readval(self.dev, 5, self.rbuff)
        if res != 0:
            self.info_print.append('dc_readval Erro!')
            return
        else:
            if self.rbuff.value == b'':
                self.info_print.append('0')
            else:
                self.data_length = len(self.MyHexA(self.rbuff.value).decode())
                self.data = ''
                for i in range(int(self.data_length / 2)):
                    self.data += self.MyHexA(self.rbuff.value).decode()[
                                 int((self.data_length / 2 - i - 1)) * 2:int((self.data_length / 2 - i)) * 2]

                self.info_print.append(str(int(self.data, 16)))



    def info_print_func(self):
        self.info_print.show()