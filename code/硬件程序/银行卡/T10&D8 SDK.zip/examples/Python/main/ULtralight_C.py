# -*- coding: utf-8 -*-


from TypeCastSimple import *

class ULtralight_C():

    def __init__(self,dev,dll,info_print):
        self.dev = dev
        self.dll = dll
        self.info_print = info_print
        self.rbuff = TypeFactory("UCHAR *", 128)
        self.rlen = TypeFactory("UCHAR *", 64)


    def MyAHex(self,str):
        return binascii.a2b_hex(str.replace(' ', ''))

    def MyHexA(self,str):
        return binascii.b2a_hex(str).upper()

    def run(self):
        self.dll.dc_beep(self.dev,10)

        #//射频复位
        self.dll.dc_reset(self.dev, 1)

        # 寻卡并返回卡序列号
        res = self.dll.dc_card_n(self.dev, 0, self.rlen, self.rbuff)
        if res != 0:
            self.info_print.append('dc_card_n_Error!')
            return
        else:
            self.info_print.append('dc_card_n OK!')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())
            # print(self.MyHexA(self.rbuff.value).decode())

        #验证Mifare Ultralight C卡密码
        res=self.dll.dc_auth_ulc_hex(self.dev,'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'.encode())
        if res !=0:
            self.info_print.append('dc_auth_ulc_hex Error!')
            return
        else:
            self.info_print.append('dc_auth_ulc_hex OK!')

        # 写卡数据
        res=self.dll.dc_write_hex(self.dev,1,'31323334353637383930313233343536'.encode())
        if res !=0:
            self.info_print.append('dc_write_hex Error!')
            return

        else:
            self.info_print.append('dc_write_hex OK!')

        #读扇区
        res=self.dll.dc_read(self.dev,1,self.rbuff)
        if res !=0:
            self.info_print.append('dc_read Error!')
            return
        else:
            self.info_print.append('dc_read OK!')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())









    def info_print_func(self):
        self.info_print.show()
