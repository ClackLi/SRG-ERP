# -*- coding: utf-8 -*-


from TypeCastSimple import *

class MiFarePlus():

    def __init__(self,dev,dll,info_print):
        self.dev = dev
        self.dll = dll
        self.info_print = info_print
        self.rbuff = TypeFactory("UCHAR *", 128)
        self.rlen = TypeFactory("UCHAR *", 64)


    def MyAHex(self,str):
        return binascii.a2b_hex(str.replace(' ', ''))

    def MyHexA(self,str):
        return binascii.b2a_hex(str).upper()

    def run(self):
        self.dll.dc_beep(self.dev,10)

        #//射频复位
        self.dll.dc_reset(self.dev, 1)

        # 寻卡并返回卡序列号
        res = self.dll.dc_card_n(self.dev, 0, self.rlen, self.rbuff)
        if res != 0:
            self.info_print.append('dc_card_n_Error!')
            return
        else:
            self.info_print.append('dc_card_n OK!')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())
            # print(self.MyHexA(self.rbuff.value).decode())

        res=self.dll.dc_pro_reset(self.dev,self.rlen,self.rbuff)
        if res !=0:
            self.info_print.append('dc_pro_reset Error!')
            return
        else:
            self.info_print.append('dc_pro_reset OK!')
            self.info_print.append(self.MyHexA(self.rbuff.value).decode())

        res=self.dll.dc_MFPL0_writeperso_hex(self.dev,0x9000,'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'.encode())
        if res !=0:
            self.info_print.append('dc_MFPL0_writeperso_hex Error!')
            return
        else:
            self.info_print.append('dc_MFPL0_writeperso_hex OK!')



    def info_print_func(self):
        self.info_print.show()
