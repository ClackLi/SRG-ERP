# -*- coding: utf-8 -*-


from TypeCastSimple import *
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QGraphicsView,QGraphicsScene


class ID():

    def __init__(self,dev,dll,info_print,*args):
        self.dev = dev
        self.dll = dll
        self.info_print = info_print
        self.ID_Image=args[0]
        self.rbuff=TypeFactory("UCHAR *",128)
        # self.text_len=TypeFactory("UCHAR *",64)
        self.text_len=c_int(0)
        self.text=TypeFactory("UCHAR *",256)


        # self.photo_len=c_int(0)
        self.photo_len=c_int(0)
        self.photo=TypeFactory("UCHAR *",1024)
        self.fingerprint_len=TypeFactory("UCHAR *",64)
        self.fingerprint=TypeFactory("UCHAR *",1024)
        self.extra_len=TypeFactory("UCHAR *",64)
        self.extra=TypeFactory("UCHAR *",70)
        self.type=0


        #身份证信息
        self.name = TypeFactory("UCHAR *", 64)
        self.sex = TypeFactory("UCHAR *", 8)
        self.nation = TypeFactory("UCHAR *", 12)
        self.birth_day = TypeFactory("UCHAR *", 36)
        self.address = TypeFactory("UCHAR *", 144)
        self.id_number = TypeFactory("UCHAR *", 76)
        self.department = TypeFactory("UCHAR *", 64)
        self.expire_start_day = TypeFactory("UCHAR *", 36)
        self.expire_end_day = TypeFactory("UCHAR *", 36)
        self.reserved = TypeFactory("UCHAR *", 76)
        self.info_buffer = TypeFactory("UCHAR *", 64)





    def MyAHex(self,str):
        return binascii.a2b_hex(str.replace(' ', ''))

    def MyHexA(self,str):
        return binascii.b2a_hex(str).upper()

    def run(self):
        try:

            self.dll.dc_beep(self.dev,10)

            #//射频复位
            self.dll.dc_reset(self.dev, 1)

            #设置卡类型
            self.dll.dc_config_card(self.dev,'B')

            # 寻卡并返回卡序列号

            res = self.dll.dc_card_b(self.dev,self.rbuff)
            if res != 0:
                self.info_print.append('dc_card_b Error!')
                return
            else:
                self.info_print.append('dc_card_b OK!')

            self.info_print.append('\n-------- Read ID INFORMATION--------\n')

            res=self.dll.dc_SamAReadCardInfo(self.dev,3,byref(self.text_len),self.text,byref(self.photo_len),self.photo,self.fingerprint_len,self.fingerprint,self.extra_len,self.extra)
            # print(self.photo_len, self.photo_len.value)
            # print(self.photo, self.photo.raw)
            
            if res !=0:
                self.info_print.append('dc_SamAReadCardInfo Error!')
                return
            else:
                self.info_print.append('dc_SamAReadCardInfo OK!\n')


            if self.text[0].decode()>='A' and self.text[0].decode()<='Z' and  self.MyHexA(self.text[1]).decode() == str(0):
                self.type=1

            if self.type==0:
                self.info_print.append('dc_ParseTextInfo ... \n')
                res=self.dll.dc_ParseTextInfo(self.dev,0,self.text_len.value, self.text,
                                self.name, self.sex, self.nation, self.birth_day, self.address, self.id_number, self.department,
                                self.expire_start_day, self.expire_end_day, self.reserved)
                if res !=0:
                    self.info_print.append('dc_ParseTextInfo Error!\n')
                    return

                self.info_print.append('dc_ParseTextInfo ok!\n')
                self.info_print.append('name:'+self.name.value.decode('gbk')+'\n')
                self.dll.dc_ParseOtherInfo(self.dev, 0, self.sex, self.info_buffer)
                self.info_print.append('sex:'+self.info_buffer.value.decode('gbk')+'\n')
                self.dll.dc_ParseOtherInfo(self.dev, 1, self.nation, self.info_buffer)
                self.info_print.append('nation:'+self.info_buffer.value.decode('gbk')+'\n')
                self.info_print.append('birth_day:'+self.birth_day.value.decode('gbk')+'\n')
                self.info_print.append('address:'+self.address.value.decode('gbk')+'\n')
                self.info_print.append('id_number:'+self.id_number.value.decode('gbk')+'\n')
                self.info_print.append('department:'+self.department.value.decode('gbk')+'\n')
                self.info_print.append('expire_start_day:'+self.expire_start_day.value.decode('gbk')+'\n')
                self.info_print.append('expire_end_day:'+self.expire_end_day.value.decode('gbk')+'\n')

            elif self.type==1:
                self.engligh_name = TypeFactory("UCHAR *", 244)
                self.citizenship = TypeFactory("UCHAR *", 16)
                self.chinese_name = TypeFactory("UCHAR *", 64)
                self.version_number = TypeFactory("UCHAR *", 12)
                self.department_code = TypeFactory("UCHAR *", 20)
                self.type_sign = TypeFactory("UCHAR *", 8)

                self.info_print.append('dc_ParseTextInfoForForeigner ... \n')

                res = self.dll.dc_ParseTextInfoForForeigner(self.dev, 0, self.text_len.value, self.text, self.english_name, self.sex, self.id_number,
                                                            self.citizenship, self.chinese_name, self.expire_start_day, self.expire_end_day,
                                                            self.birth_day, self.version_number, self.department_code, self.type_sign, self.reserved)
                if res !=0:
                    self.info_print.append('dc_ParseTextInfoForForeigner error!\n')
                    return
                else:
                    self.info_print.append('dc_ParseTextInfoForForeigner OK!\n')
                    self.info_print.append('engligh_name:' + self.engligh_name.value.decode('gbk') + '\n')
                    self.dll.dc_ParseOtherInfo(self.dev,0,self.sex,self.info_buffer)
                    self.info_print.append('sex:' + self.sex.value.decode('gbk') + '\n')
                    self.info_print.append('id_number:' + self.id_number.value.decode('gbk') + '\n')
                    self.dll.dc_ParseOtherInfo(self.dev, 2, self.citizenship, self.info_buffer)
                    self.info_print.append('citizenship:' + self.citizenship.value.decode('gbk') + '\n')
                    self.info_print.append('chinese_name:' + self.chinese_name.value.decode('gbk') + '\n')
                    self.info_print.append('expire_start_day:' + self.expire_start_day.value.decode('gbk') + '\n')
                    self.info_print.append('expire_end_day:' + self.expire_end_day.value.decode('gbk') + '\n')
                    self.info_print.append('birth_day:' + self.birth_day.value.decode('gbk') + '\n')
                    self.info_print.append('version_number:' + self.version_number.value.decode('gbk') + '\n')
                    self.info_print.append('department_code:' + self.department_code.value.decode('gbk') + '\n')
                    self.info_print.append('type_sign:' + self.type_sign.value.decode('gbk') + '\n')

            #获取照片
            self.info_print.append('dc_ParsePhotoInfo ... \n')
            res=self.dll.dc_ParsePhotoInfo(self.dev,0,self.photo_len.value,self.photo.raw[:self.photo_len.value],0,b'me.bmp')

            if res !=0:
                self.info_print.append('dc_ParsePhotoInfo error!\n')
                return
            else:
                scene=QGraphicsScene()
                scene.addPixmap(QPixmap('me.bmp'))
                self.ID_Image.setScene(scene)
                self.ID_Image.show()


            res=self.dll.dc_IdCardImageBuild(self.dev,self.type,self.text_len.value,
                                             self.text.raw[:self.text_len.value],self.photo_len.value,
                                             self.photo.raw[:self.photo_len.value],b'front.bmp',b'back.bmp')

            if res !=0:
                self.info_print.append('dc_IdCardImageBuild error!\n')
                return
            else:
                self.info_print.append('dc_IdCardImageBuild OK!\n')

        except Exception as e:
            print(e)



    def info_print_func(self):
        self.info_print.show()
