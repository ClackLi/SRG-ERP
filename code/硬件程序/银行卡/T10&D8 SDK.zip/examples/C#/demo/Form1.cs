﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace demo
{
    public partial class Form1 : Form
    {
        [DllImport("winmm")]
        static extern uint timeGetTime();
        [DllImport("winmm")]
        static extern void timeBeginPeriod(int t);
        [DllImport("winmm")]
        static extern void timeEndPeriod(int t);
        [DllImport("dcrf32.dll")]
        public static extern short dc_init(Int16 port, int baud);  //初试化
        [DllImport("dcrf32.dll")]
        public static extern short dc_exit(int icdev);
        [DllImport("dcrf32.dll")]
        public static extern short dc_reset(int icdev, uint sec);
        [DllImport("dcrf32.dll")]
        public static extern short dc_config_card(int icdev, char cardtype);  //初试化
        //short USER_API dc_card_n(HANDLE icdev, unsigned char _Mode, unsigned int* SnrLen, unsigned char* _Snr);
        [DllImport("dcrf32.dll")]
        public static extern short dc_card_n(int icdev, byte _Mode,ref uint SnrLen, [Out]byte[] _Snr);
        //short USER_API dc_beep(HANDLE icdev, unsigned short _Msec);
        [DllImport("dcrf32.dll")]
        public static extern short dc_beep(int icdev, ushort _Msec);
        //short USER_API dc_authentication_passaddr(HANDLE icdev, unsigned char _Mode, unsigned char _Addr, unsigned char* passbuff);
        [DllImport("dcrf32.dll")]
        public static extern short dc_authentication_passaddr(int icdev, byte _Mode,byte _Addr, [In]byte[] passbuff);
        //short USER_API dc_write(HANDLE icdev, unsigned char _Adr, unsigned char* _Data);
        [DllImport("dcrf32.dll")]
        public static extern short dc_write(int icdev, byte adr, [In] byte[] sdata);  //向卡中写入数据
        //short USER_API dc_write_hex(HANDLE icdev, unsigned char _Adr, char *_Data);
        [DllImport("dcrf32.dll")]
        public static extern short dc_write_hex(int icdev, int adr, [In] byte[] sdata);  //向卡中写入数据(转换为16进制)
        //short USER_API dc_read(HANDLE icdev, unsigned char _Adr, unsigned char *_Data);
        [DllImport("dcrf32.dll")]
        public static extern short dc_read(int icdev, byte adr, [Out] byte[] sdata);  //从卡中读数据
        //short USER_API dc_read_hex(HANDLE icdev, unsigned char _Adr, char *_Data);
        [DllImport("dcrf32.dll")]
        public static extern short dc_read_hex(int icdev, int adr, [Out] byte[] sdata);  //从卡中读数据(转换为16进制)
        //short USER_API a_hex(unsigned char *a, unsigned char *hex, short len);
        [DllImport("dcrf32.dll")]
        public static extern short a_hex([In] byte[] a, [Out] byte[] hex, short len);  //普通字符转换成十六进制字符
        //short USER_API hex_a(unsigned char *hex, unsigned char *a, short length);
        [DllImport("dcrf32.dll")]
        public static extern short hex_a([In] byte[] hex, [Out] byte[] a, short length);  //普通字符转换成十六进制字符
        //short USER_API dc_initval(HANDLE icdev, unsigned char _Adr, unsigned int _Value);
        [DllImport("dcrf32.dll")]
        public static extern short dc_initval(int icdev, byte _Adr, uint _Value);  //普通字符转换成十六进制字符
        // short USER_API dc_readval(HANDLE icdev, unsigned char _Adr, unsigned int *_Value);
        [DllImport("dcrf32.dll")]
        public static extern short dc_readval(int icdev, byte _Adr,ref uint _Value);  //普通字符转换成十六进制字符
        // short USER_API dc_increment(HANDLE icdev, unsigned char _Adr, unsigned int _Value);
        [DllImport("dcrf32.dll")]
        public static extern short dc_increment(int icdev, byte _Adr, uint _Value);  //普通字符转换成十六进制字符
        // short USER_API dc_decrement(HANDLE icdev, unsigned char _Adr, unsigned int _Value);
        [DllImport("dcrf32.dll")]
        public static extern short dc_decrement(int icdev, byte _Adr, uint _Value);  //普通字符转换成十六进制字符
        //short USER_API dc_restore(HANDLE icdev, unsigned char _Adr);
        [DllImport("dcrf32.dll")]
        public static extern short dc_restore(int icdev, byte _Adr);  //普通字符转换成十六进制字符
        //short USER_API dc_transfer(HANDLE icdev, unsigned char _Adr);
        [DllImport("dcrf32.dll")]
        public static extern short dc_transfer(int icdev, byte _Adr);  //普通字符转换成十六进制字符
        //short USER_API dc_pro_resetInt(HANDLE icdev, unsigned char *rlen, unsigned char *receive_data);
        [DllImport("dcrf32.dll")]
        public static extern short dc_pro_resetInt(int icdev, ref byte rlen,[Out]byte[] receive_data);  //普通字符转换成十六进制字符
        //short USER_API dc_pro_commandlinkInt(HANDLE icdev, unsigned int slen, unsigned char *sendbuffer, unsigned int *rlen, unsigned char *databuffer, unsigned char timeout);
        [DllImport("dcrf32.dll")]
        public static extern short dc_pro_commandlinkInt(int icdev,uint slen, [In]byte[] sendbuffer,ref uint rlen,[Out]byte[] databuffer,byte timeout);  //普通字符转换成十六进制字符
        //short USER_API dc_card_b(HANDLE icdev, unsigned char *rbuf);
        [DllImport("dcrf32.dll")]
        public static extern short dc_card_b(int icdev,  [Out]byte[] rbuf);  //普通字符转换成十六进制字符
        // short USER_API dc_MFPL0_writeperso(HANDLE icdev, unsigned int BNr, unsigned char *dataperso);
        [DllImport("dcrf32.dll")]
        public static extern short dc_MFPL0_writeperso(int icdev, [In]uint BNr,[Out]byte[] dataperso);  //普通字符转换成十六进制字符
        //short USER_API dc_auth_ulc(HANDLE icdev, unsigned char *key);
        [DllImport("dcrf32.dll")]
        public static extern short dc_auth_ulc(int icdev, [In]byte[] key);  //普通字符转换成十六进制字符
        //short USER_API dc_verifypin_4442(HANDLE icdev, unsigned char *passwd);
        [DllImport("dcrf32.dll")]
        public static extern short dc_verifypin_4442(int icdev, [In]byte[] passwd);  //普通字符转换成十六进制字符
        //short USER_API dc_write_4442(HANDLE icdev, short offset, short length, unsigned char *data_buffer);
        [DllImport("dcrf32.dll")]
        public static extern short dc_write_4442(int icdev, short offset, short length, [In]byte[] data_buffer);  //普通字符转换成十六进制字符
        //short USER_API dc_read_4442(HANDLE icdev, short offset, short length, unsigned char *data_buffer);
        [DllImport("dcrf32.dll")]
        public static extern short dc_read_4442(int icdev, short offset, short length, [Out]byte[] data_buffer);  //普通字符转换成十六进制字符
        [DllImport("dcrf32.dll")]
        public static extern short dc_verifypin_4428(int icdev, [In]byte[] passwd);  //普通字符转换成十六进制字符
        //short USER_API dc_write_4442(HANDLE icdev, short offset, short length, unsigned char *data_buffer);
        [DllImport("dcrf32.dll")]
        public static extern short dc_write_4428(int icdev, short offset, short length, [In]byte[] data_buffer);  //普通字符转换成十六进制字符
        //short USER_API dc_read_4442(HANDLE icdev, short offset, short length, unsigned char *data_buffer);
        [DllImport("dcrf32.dll")]
        public static extern short dc_read_4428(int icdev, short offset, short length, [Out]byte[] data_buffer);  //普通字符转换成十六进制字符
        //short USER_API dc_setcpu(HANDLE icdev, unsigned char _Byte);
        [DllImport("dcrf32.dll")]
        public static extern short dc_setcpu(int icdev, [In]byte _Byte);  //普通字符转换成十六进制字符
        //short USER_API dc_write_24c(HANDLE icdev, short offset, short length, unsigned char *data_buffer);
        [DllImport("dcrf32.dll")]
        public static extern short dc_write_24c(int icdev, short offset, short length, [In]byte[] data_buffer);  //普通字符转换成十六进制字符
        //short USER_API dc_read_4442(HANDLE icdev, short offset, short length, unsigned char *data_buffer);
        [DllImport("dcrf32.dll")]
        public static extern short dc_read_24c(int icdev, short offset, short length, [Out]byte[] data_buffer);  //普通字符转换成十六进制字符
        //short USER_API dc_cpureset(HANDLE icdev, unsigned char *rlen, unsigned char *databuffer);
        [DllImport("dcrf32.dll")]
        public static extern short dc_cpureset(int icdev, ref byte rlen, [Out]byte[] databuffer);  //普通字符转换成十六进制字符
        //short USER_API dc_cpuapduInt(HANDLE icdev, unsigned int slen, unsigned char *sendbuffer, unsigned int *rlen, unsigned char *databuffer);
        [DllImport("dcrf32.dll")]
        public static extern short dc_cpuapduInt(int icdev, uint slen, [In]byte[] sendbuffer, ref uint rlen, [Out]byte[] databuffer);  //普通字符转换成十六进制字符
        [DllImport("dcrf32.dll")]
        public static extern short dc_SamAReadCardInfo(int handle, int type, ref int text_len, [Out]byte[] text, ref int photo_len, [Out]byte[] photo, ref int fingerprint_len, [Out]byte[] fingerprint, ref int extra_len, [Out] byte[] extra);

        [DllImport("dcrf32.dll")]
        public static extern short dc_find_i_d(int handle);
        [DllImport("dcrf32.dll")]
        public static extern int dc_start_i_d(int handle);
        [DllImport("dcrf32.dll")]
        public static extern IntPtr dc_i_d_query_name(int handle);
        [DllImport("dcrf32.dll")]
        public static extern IntPtr dc_i_d_query_sex(int handle);
        [DllImport("dcrf32.dll")]
        public static extern IntPtr dc_i_d_query_nation(int handle);
        [DllImport("dcrf32.dll")]
        public static extern IntPtr dc_i_d_query_birth(int handle);
        [DllImport("dcrf32.dll")]
        public static extern IntPtr dc_i_d_query_address(int handle);
        [DllImport("dcrf32.dll")]
        public static extern IntPtr dc_i_d_query_id_number(int handle);
        [DllImport("dcrf32.dll")]
        public static extern IntPtr dc_i_d_query_department(int handle);
        [DllImport("dcrf32.dll")]
        public static extern IntPtr dc_i_d_query_expire_day(int handle);
        [DllImport("dcrf32.dll")]
        public static extern short dc_i_d_query_photo_bmp_buffer(int handle, [Out]byte[] bmp_buffer, ref int bmp_len);
        [DllImport("dcrf32.dll")]
        public static extern short dc_i_d_query_photo_file(int handle, [Out]byte[] FileName);
        [DllImport("dcrf32.dll")]
        public static extern short dc_end_i_d(int handle);
        [DllImport("dcrf32.dll")]
        public static extern short dc_ParseTextInfo(int handle, int charset, int info_len, [Out]byte[] info, [Out]byte[] name, [Out]byte[] sex, [Out]byte[] nation, [Out]byte[] birth_day, [Out]byte[] address, [Out]byte[] id_number, [Out]byte[] department, [Out] byte[] expire_start_day, [Out]byte[] expire_end_day, [Out] byte[] reserved);
        [DllImport("dcrf32.dll")]
        public static extern short dc_ParseTextInfoForForeigner(int handle, int charset, int info_len, [Out]byte[] info, [Out]byte[] english_name, [Out]byte[] sex, [Out]byte[] id_number, [Out]byte[] citizenship, [Out] byte[] chinese_name, [Out]byte[] expire_start_day, [Out] byte[] expire_end_day, [Out] byte[] birth_day, [Out]byte[] version_number, [Out]byte[] department_code, [Out] byte[] type_sign, [Out]byte[] reserved);
        [DllImport("dcrf32.dll")]
        public static extern short dc_ParsePhotoInfo(int handle, int type, int info_len, [Out]byte[] info, ref int photo_len, [Out]byte[] photo);
        [DllImport("dcrf32.dll")]
        public static extern short dc_ParseOtherInfo(int icdev, int flag, [In]byte[] in_info, [Out]byte[] out_info);
        [DllImport("dcrf32.dll")]
        public static extern short dc_Scan2DBarcodeStart(int icdev, byte mode);
        [DllImport("dcrf32.dll")]
        public static extern short dc_Scan2DBarcodeGetData(int icdev, ref int rlen, [Out]byte[] rdata);
        [DllImport("dcrf32.dll")]
        public static extern short dc_Scan2DBarcodeExit(int icdev);
        public void editAddString(string str)
        {
            richTextBox1.AppendText(str);
            richTextBox1.AppendText("\r\n");
            return;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            uint SnrLen = 0;
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0,3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //射频复位
            dc_reset(icdev, 1);
            //设置卡型
            st = dc_config_card(icdev, 'A');
            //寻卡并返回卡序列号
            st = dc_card_n(icdev, 0x00, ref SnrLen, _Snr);
            if (st != 0)
            {
                editAddString("dc_card_n Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_card_n Ok!");
                for (int i = 0; i < 4; i++)
                {
                    _Snr[i] = _Snr[3 - i];
                }
                hex_a(_Snr, szSnr, 4);
                str = System.Text.Encoding.Default.GetString(szSnr);
                editAddString(str);
                
            }
            //验证卡密码
            byte[] password = new byte[7];
            password[0] = 0xff;
            password[1] = 0xff;
            password[2] = 0xff;
            password[3] = 0xff;
            password[4] = 0xff;
            password[5] = 0xff;
            password[6] = 0xff;
            st = dc_authentication_passaddr(icdev, 0, 7, password);
            if (st != 0)
            {
                editAddString("dc_authentication_passaddr Error!");
                goto safeExit;
            }
            else
                editAddString("dc_authentication_passaddr OK!");
            //写扇区
            byte[] writedata = new byte[33];
            writedata[0] = 0x30;
            writedata[1] = 0x31;
            writedata[2] = 0x32;
            writedata[3] = 0x33;
            writedata[4] = 0x34;
            writedata[5] = 0x35;
            writedata[6] = 0x36;
            writedata[7] = 0x37;
            writedata[8] = 0x38;
            writedata[9] = 0x39;
            writedata[10] = 0x30;
            writedata[11] = 0x31;
            writedata[12] = 0x32;
            writedata[13] = 0x33;
            writedata[14] = 0x34;
            writedata[15] = 0x35;
            writedata[16] = 0x36;
            st = dc_write(icdev, 4, writedata);
            if (st != 0)
            {
                editAddString("dc_write Error!");
                goto safeExit;
            }
            else
                editAddString("dc_write OK!");
            byte[] rdata = new byte[33];
            byte[] rdatahex = new byte[33];
            //读扇区
            st = dc_read(icdev, 4, rdata);
            if (st != 0)
            {
                editAddString("dc_read Error!");
                goto safeExit;
            }
            else
            {
                hex_a(rdata, rdatahex, 16);
                str = System.Text.Encoding.Default.GetString(rdatahex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev =  - 1;
                }
            }
            return;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            uint SnrLen = 0;           
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //射频复位
            dc_reset(icdev, 1);
            //设置卡型
            st = dc_config_card(icdev, 'A');
            //寻卡并返回卡序列号
            st = dc_card_n(icdev, 0x00, ref SnrLen, _Snr);
            if (st != 0)
            {
                editAddString("dc_card_n Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_card_n Ok!");
                for (int i = 0; i < 4; i++)
                {
                    _Snr[i] = _Snr[3 - i];
                }
                hex_a(_Snr, szSnr, 4);
                str = System.Text.Encoding.Default.GetString(szSnr);
                editAddString(str);
                
            }
            //验证卡密码
            byte[] password = new byte[7];
            password[0] = 0xff;
            password[1] = 0xff;
            password[2] = 0xff;
            password[3] = 0xff;
            password[4] = 0xff;
            password[5] = 0xff;
            password[6] = 0xff;
            st = dc_authentication_passaddr(icdev, 0, 7, password);
            if (st != 0)
            {
                editAddString("dc_authentication_passaddr Error!");
                goto safeExit;
            }
            else
                editAddString("dc_authentication_passaddr OK!");
            //块值初始化为0
            st = dc_initval(icdev, 5, 0);
            if (st != 0)
            {
                editAddString("dc_initval Error!");
                goto safeExit;
            }
            else
                editAddString("dc_initval OK!");
            //读块值
            uint ivalue = 0;
            string cvalue;
            st = dc_readval(icdev, 5, ref ivalue);
            if (st != 0)
            {
                editAddString("dc_readval Erro!");
                return;
            }
            else
            {
                cvalue = ivalue.ToString();
                editAddString(cvalue);
                
            }
            //块加值
            st = dc_increment(icdev, 5, 1000);
            if (st != 0)
            {
                editAddString("dc_increment Error!");
                goto safeExit;
            }
            else
                editAddString("dc_increment OK!");
            //读块值
            st = dc_readval(icdev, 5, ref ivalue);
            if (st != 0)
            {
                editAddString("dc_readval Erro!");
                return;
            }
            else
            {
                cvalue = ivalue.ToString();
                editAddString(cvalue);
                
            }
            //块减值
            st = dc_decrement(icdev, 5, 100);
            if (st != 0)
            {
                editAddString("dc_decrement Error!");
                goto safeExit;
            }
            else
                editAddString("dc_decrement OK!");
            //读块值
            st = dc_readval(icdev, 5, ref ivalue);
            if (st != 0)
            {
                editAddString("dc_readval Erro!");
                return;
            }
            else
            {
                cvalue = ivalue.ToString();
                editAddString(cvalue);
                
            }
            //块值传递
            st = dc_restore(icdev, 5);
            if (st != 0)
            {
                editAddString("dc_restore Error!");
                goto safeExit;
            }
            else
                editAddString("dc_restore OK!");
            st = dc_transfer(icdev, 6);
            if (st != 0)
            {
                editAddString("dc_transfer Error!");
                goto safeExit;
            }
            else
                editAddString("dc_transfer OK!");
            //读块值
            st = dc_readval(icdev, 6, ref ivalue);
            if (st != 0)
            {
                editAddString("dc_readval Erro!");
                goto safeExit;
            }
            else
            {
                cvalue = ivalue.ToString();
                editAddString(cvalue);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = - 1;
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            uint SnrLen = 0;          
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //射频复位
            dc_reset(icdev, 1);
            //设置卡型
            //寻卡并返回卡序列号
            st = dc_card_n(icdev, 0x00, ref SnrLen, _Snr);
            if (st != 0)
            {
                editAddString("dc_card_n Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_card_n Ok!");
                hex_a(_Snr, szSnr, (short)SnrLen);
                str = System.Text.Encoding.Default.GetString(szSnr);
                editAddString(str);
                
            }
            byte[] key = new byte[7];
            key[0] = 0xFF;
            key[1] = 0xFF;
            key[2] = 0xFF;
            key[3] = 0xFF;
            key[4] = 0xFF;
            key[5] = 0xFF;
            st =  dc_auth_ulc(icdev, key);
            if (st != 0)
            {
                editAddString("dc_auth_ulc Error!");
                return;
            }
            else
            {
                editAddString("dc_auth_ulc Ok!");
            }
            byte[] writedata = new byte[33];
            writedata[0] = 0x30;
            writedata[1] = 0x31;
            writedata[2] = 0x32;
            writedata[3] = 0x33;
            writedata[4] = 0x34;
            writedata[5] = 0x35;
            writedata[6] = 0x36;
            writedata[7] = 0x37;
            writedata[8] = 0x38;
            writedata[9] = 0x39;
            writedata[10] = 0x30;
            writedata[11] = 0x31;
            writedata[12] = 0x32;
            writedata[13] = 0x33;
            writedata[14] = 0x34;
            writedata[15] = 0x35;
            writedata[16] = 0x36;
            st = dc_write(icdev, 4, writedata);
            if (st != 0)
            {
                editAddString("dc_write Error!");
                goto safeExit;
            }
            else
                editAddString("dc_write OK!");
            byte[] rdata = new byte[33];
            byte[] rdatahex = new byte[33];
            //读扇区
            st = dc_read(icdev, 4, rdata);
            if (st != 0)
            {
                editAddString("dc_read Error!");
                goto safeExit;
            }
            else
            {
                hex_a(rdata, rdatahex, 16);
                str = System.Text.Encoding.Default.GetString(rdatahex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
            return;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //验证卡密码
            byte[] password = new byte[4];
            password[0] = 0xff;
            password[1] = 0xff;
            st = dc_verifypin_4428(icdev, password);
            if (st != 0)
            {
                editAddString("dc_authentication_passaddr Error!");
                goto safeExit;
            }
            else
                editAddString("dc_authentication_passaddr OK!");
            //写扇区
            byte[] writedata = new byte[51];
            for (int i = 0; i < 50; i++)
            {
                Random ra = new Random(i);
                writedata[i] = (byte)ra.Next(256);
            }
            st = dc_write_4428(icdev, 32, 50, writedata);
            if (st != 0)
            {
                editAddString("dc_write Error!");
                goto safeExit;
            }
            else
                editAddString("dc_write OK!");
            byte[] rdata = new byte[51];
            byte[] rdatahex = new byte[101];
            //读扇区
            st = dc_read_4428(icdev, 32, 50, rdata); ;
            if (st != 0)
            {
                editAddString("dc_read Error!");
                goto safeExit;
            }
            else
            {
                hex_a(rdata, rdatahex, 50);
                str = System.Text.Encoding.Default.GetString(rdatahex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
            return;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            uint SnrLen = 0;
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //射频复位
            dc_reset(icdev, 1);
            st = dc_config_card(icdev, 'A');
            st = dc_card_n(icdev, 0x00, ref SnrLen, _Snr);
            if (st != 0)
            {
                editAddString("dc_card_n Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_card_n Ok!");
                hex_a(_Snr, szSnr, (short)SnrLen);
                str = System.Text.Encoding.Default.GetString(szSnr);
                editAddString(str);
                
            }
            byte rcardlen = 0;
            uint rlen = 0;
            byte[] databuffer= new byte[100];
            byte[] databufferhex = new byte[100];
            st = dc_pro_resetInt(icdev, ref rcardlen, databuffer);
            if (st != 0)
            {
                editAddString("dc_pro_resetInt Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_pro_resetInt Ok!");
                hex_a(databuffer, databufferhex, (short)rcardlen);
                str = System.Text.Encoding.Default.GetString(databufferhex);
                editAddString(str);
                
            }
            byte[] sendbuffer = new byte[6];
            sendbuffer[0] = 0x00;
            sendbuffer[1] = 0x84;
            sendbuffer[2] = 0x00;
            sendbuffer[3] = 0x00;
            sendbuffer[4] = 0x08;
            st = dc_pro_commandlinkInt(icdev, 5, sendbuffer, ref rlen, databuffer, 10);
            if (st != 0)
            {
                editAddString("dc_pro_commandlinkInt Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_pro_commandlinkInt Ok!");
                hex_a(databuffer, databufferhex, (short)rlen);
                str = System.Text.Encoding.Default.GetString(databufferhex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev =  - 1;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //射频复位
            dc_reset(icdev, 1);
            st = dc_config_card(icdev, 'B');
            st = dc_card_b(icdev, _Snr);
            if (st != 0)
            {
                editAddString("dc_card_b Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_card_b Ok!");
                //SnrLen = (uint)_Snr.Length;
                hex_a(_Snr, szSnr, 11);
                str = System.Text.Encoding.Default.GetString(szSnr);
                editAddString(str);
                
            }
            uint rlen = 0;
            byte[] databuffer = new byte[100];
            byte[] databufferhex = new byte[100];
            byte[] sendbuffer = new byte[6];
            sendbuffer[0] = 0x00;
            sendbuffer[1] = 0x84;
            sendbuffer[2] = 0x00;
            sendbuffer[3] = 0x00;
            sendbuffer[4] = 0x08;
            st = dc_pro_commandlinkInt(icdev, 5, sendbuffer, ref rlen, databuffer, 10);
            if (st != 0)
            {
                editAddString("dc_pro_commandlinkInt Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_pro_commandlinkInt Ok!");
                hex_a(databuffer, databufferhex, (short)rlen);
                str = System.Text.Encoding.Default.GetString(databufferhex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            uint SnrLen = 0;           
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
           
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //射频复位
            dc_reset(icdev, 1);
            st = dc_config_card(icdev, 'A');
            st = dc_card_n(icdev, 0x00, ref SnrLen, _Snr);
            if (st != 0)
            {
                editAddString("dc_card_n Error!");
                return;
            }
            else
            {
                editAddString("dc_card_n Ok!");
                hex_a(_Snr, szSnr, (short)SnrLen);
                str = System.Text.Encoding.Default.GetString(szSnr);
                editAddString(str);
                
            }
            byte rcardlen = 0;
            uint rlen = 0;
            byte[] databuffer = new byte[100];
            byte[] databufferhex = new byte[100];
            st = dc_pro_resetInt(icdev, ref rcardlen, databuffer);
            if (st != 0)
            {
                editAddString("dc_pro_resetInt Error!");
                return;
            }
            else
            {
                editAddString("dc_pro_resetInt Ok!");
                hex_a(databuffer, databufferhex, (short)rlen);
                str = System.Text.Encoding.Default.GetString(databufferhex);
                editAddString(str);
                
            }
            byte[] sendbuffer = new byte[6];
            sendbuffer[0] = 0x00;
            sendbuffer[1] = 0x84;
            sendbuffer[2] = 0x00;
            sendbuffer[3] = 0x00;
            sendbuffer[4] = 0x08;
            st = dc_pro_commandlinkInt(icdev, 5, sendbuffer, ref rlen, databuffer, 10);
            if (st != 0)
            {
                editAddString("dc_pro_commandlinkInt Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_pro_commandlinkInt Ok!");
                hex_a(databuffer, databufferhex, (short)rlen);
                str = System.Text.Encoding.Default.GetString(databufferhex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            uint SnrLen = 0;           
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //射频复位
            dc_reset(icdev, 1);
            st = dc_card_n(icdev, 0x00, ref SnrLen, _Snr);
            if (st != 0)
            {
                editAddString("dc_card_n Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_card_n Ok!");
                hex_a(_Snr, szSnr, (short)SnrLen);
                str = System.Text.Encoding.Default.GetString(szSnr);
                editAddString(str);
                
            }
            byte rcardlen = 0;
            byte[] databuffer = new byte[100];
            byte[] databufferhex = new byte[100];
            st = dc_pro_resetInt(icdev, ref rcardlen, databuffer);
            if (st != 0)
            {
                editAddString("dc_pro_resetInt Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_pro_resetInt Ok!");
                hex_a(databuffer, databufferhex, (short)rcardlen);
                str = System.Text.Encoding.Default.GetString(databufferhex);
                editAddString(str);
                
            }
            databuffer[0] = 0xFF;
            databuffer[0] = 0xFF;
            databuffer[0] = 0xFF;
            databuffer[0] = 0xFF;
            databuffer[0] = 0xFF;
            databuffer[0] = 0xFF;
            databuffer[0] = 0xFF;
            databuffer[0] = 0xFF;
            st = dc_MFPL0_writeperso(icdev, 0x9000, databuffer);
            if (st !=0)
            {
                editAddString("dc_MFPL0_writeperso_hex ERRO!");
                goto safeExit;
            }
            editAddString("dc_MFPL0_writeperso_hex Ok!");
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            uint SnrLen = 0;           
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //射频复位
            dc_reset(icdev, 1);
            //设置卡型
            //寻卡并返回卡序列号
            st = dc_card_n(icdev, 0x00, ref SnrLen, _Snr);
            if (st != 0)
            {
                editAddString("dc_card_n Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_card_n Ok!");
                hex_a(_Snr, szSnr, (short)SnrLen);
                str = System.Text.Encoding.Default.GetString(szSnr);
                editAddString(str);
                
            }
            byte[] writedata = new byte[33];
            writedata[0] = 0x30;
            writedata[1] = 0x31;
            writedata[2] = 0x32;
            writedata[3] = 0x33;
            writedata[4] = 0x34;
            writedata[5] = 0x35;
            writedata[6] = 0x36;
            writedata[7] = 0x37;
            writedata[8] = 0x38;
            writedata[9] = 0x39;
            writedata[10] = 0x30;
            writedata[11] = 0x31;
            writedata[12] = 0x32;
            writedata[13] = 0x33;
            writedata[14] = 0x34;
            writedata[15] = 0x35;
            writedata[16] = 0x36;
            st = dc_write(icdev, 4, writedata);
            if (st != 0)
            {
                editAddString("dc_write Error!");
                goto safeExit;
            }
            else
                editAddString("dc_write OK!");
            byte[] rdata = new byte[33];
            byte[] rdatahex = new byte[33];
            //读扇区
            st = dc_read(icdev, 4, rdata);
            if (st != 0)
            {
                editAddString("dc_read Error!");
                goto safeExit;
            }
            else
            {
                hex_a(rdata, rdatahex, 16);
                str = System.Text.Encoding.Default.GetString(rdatahex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
            return;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //验证卡密码
            byte[] password = new byte[4];
            password[0] = 0xff;
            password[1] = 0xff;
            password[2] = 0xff;
            st = dc_verifypin_4442(icdev, password);
            if (st != 0)
            {
                editAddString("dc_authentication_passaddr Error!");
                goto safeExit;
            }
            else
                editAddString("dc_authentication_passaddr OK!");
            //写扇区
            byte[] writedata = new byte[51];
            for(int i = 0;i <50;i++)
            {
                Random ra = new Random(i);
                writedata[i] = (byte)ra.Next(256);
            }
            st = dc_write_4442(icdev, 32,50, writedata);
            if (st != 0)
            {
                editAddString("dc_write Error!");
                goto safeExit;
            }
            else
                editAddString("dc_write OK!");
            byte[] rdata = new byte[51];
            byte[] rdatahex = new byte[101];
            //读扇区
            st = dc_read_4442(icdev, 32, 50, rdata); ;
            if (st != 0)
            {
                editAddString("dc_read Error!");
                goto safeExit;
            }
            else
            {
                hex_a(rdata, rdatahex, 50);
                str = System.Text.Encoding.Default.GetString(rdatahex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
            return;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            byte[] writedata = new byte[51];
            for (int i = 0; i < 50; i++)
            {
                Random ra = new Random(i);
                writedata[i] = (byte)ra.Next(256);
            }
            st = dc_write_24c(icdev, 32, 50, writedata);
            if (st != 0)
            {
                editAddString("dc_write Error!");
                goto safeExit;
            }
            else
                editAddString("dc_write OK!");
            byte[] rdata = new byte[51];
            byte[] rdatahex = new byte[101];
            //读扇区
            st = dc_read_24c(icdev, 32, 50, rdata); ;
            if (st != 0)
            {
                editAddString("dc_read Error!");
                goto safeExit;
            }
            else
            {
                hex_a(rdata, rdatahex, 50);
                str = System.Text.Encoding.Default.GetString(rdatahex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
            return;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string str;
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            //射频复位
            st = dc_setcpu(icdev, 0x0D); 
            if (st != 0)
            {
                editAddString("dc_setcpu Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_setcpu Ok!");
            }
            byte rcardlen = 0;
            uint rlen = 0;
            byte[] databuffer = new byte[100];
            byte[] databufferhex = new byte[100];
            st = dc_cpureset(icdev, ref rcardlen, databuffer);
            if (st != 0)
            {
                editAddString("dc_cpureset Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_cpureset Ok!");
                hex_a(databuffer, databufferhex, (short)rlen);
                str = System.Text.Encoding.Default.GetString(databufferhex);
                editAddString(str);
                
            }
            byte[] sendbuffer = new byte[6];
            sendbuffer[0] = 0x00;
            sendbuffer[1] = 0x84;
            sendbuffer[2] = 0x00;
            sendbuffer[3] = 0x00;
            sendbuffer[4] = 0x08;
            st = dc_cpuapduInt(icdev, 5, sendbuffer, ref rlen, databuffer);
            if (st != 0)
            {
                editAddString("dc_cpuapduInt Error!");
                goto safeExit;
            }
            else
            {
                editAddString("dc_cpuapduInt Ok!");
                hex_a(databuffer, databufferhex, (short)rlen);
                str = System.Text.Encoding.Default.GetString(databufferhex);
                editAddString(str);
                
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            short iport = 0;
            string selectPort = comboBox1.Text ;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;
            
            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            dc_beep(icdev, 10);
            int result = -1;
            int text_len = 0;
            byte[] text = new byte[256];
            int photo_len = 204800;
            byte[] photo= new byte[204800];
            int fingerprint_len = 0;
            byte[] fingerprint= new byte[1024];
            int extra_len = 0;
            byte[] extra= new byte[70];
            int type = 0;
            string tempbuffer;

            editAddString("-------- Read ID INFORMATION--------");

            /*editAddString("dc_SamAReadCardInfo ...");
            result = dc_SamAReadCardInfo(icdev, 3, ref text_len, text, ref photo_len, photo, ref fingerprint_len, fingerprint, ref extra_len, extra);
            if (result != 0)
            {
                editAddString(" dc_SamAReadCardInfo error!");
                goto safeExit;
            }
            editAddString("dc_SamAReadCardInfo ok!");

            if ((text[0] >= 'A') && (text[0] <= 'Z') && (text[1] == 0))
            {
                type = 1;
            }

            if (type == 0)
            {
                byte[] name= new byte[64];
                byte[] sex= new byte[8];
                byte[] nation= new byte[12];
                byte[] birth_day= new byte[36];
                byte[] address= new byte[144];
                byte[] id_number= new byte[76];
                byte[] department= new byte[64];
                byte[] expire_start_day= new byte[36];
                byte[] expire_end_day= new byte[36];
                byte[] reserved= new byte[76];
                byte[] info_buffer= new byte[64];

                editAddString("dc_ParseTextInfo ... ");
                result = dc_ParseTextInfo(icdev, 0, text_len, text, name, sex, nation, birth_day, address, id_number, department, expire_start_day, expire_end_day, reserved);
                if (result != 0)
                {
                    editAddString("dc_ParseTextInfo error!");
                    goto safeExit;
                }
                editAddString("dc_ParseTextInfo ok!");

                tempbuffer = string.Format( "name: {0}", System.Text.Encoding.Default.GetString(name));
                editAddString(tempbuffer);
                dc_ParseOtherInfo(icdev, 0, sex, info_buffer);
                tempbuffer = string.Format( "sex: {0}", System.Text.Encoding.Default.GetString(info_buffer));
                editAddString(tempbuffer);
                dc_ParseOtherInfo(icdev, 1, nation, info_buffer);
                tempbuffer = string.Format("nation: {0}", System.Text.Encoding.Default.GetString(info_buffer));

                editAddString(tempbuffer);

                tempbuffer = string.Format( "birth_day: {0}", System.Text.Encoding.Default.GetString(birth_day));
                editAddString(tempbuffer);

                tempbuffer = string.Format( "address: {0}", System.Text.Encoding.Default.GetString(address));
                editAddString(tempbuffer);

                tempbuffer = string.Format( "id_number: {0}", System.Text.Encoding.Default.GetString(id_number));
                editAddString(tempbuffer);

                tempbuffer = string.Format( "department: {0}", System.Text.Encoding.Default.GetString(department));
                editAddString(tempbuffer);

                tempbuffer = string.Format( "expire_start_day: {0}", System.Text.Encoding.Default.GetString(expire_start_day));
                editAddString(tempbuffer);

                tempbuffer = string.Format( "expire_end_day: {0}", System.Text.Encoding.Default.GetString(expire_end_day));
                editAddString(tempbuffer);
            }
            else if (type == 1)
            {
                byte[] english_name= new byte[244];
                byte[] sex= new byte[8];
                byte[] id_number= new byte[64];
                byte[] citizenship= new byte[16];
                byte[] chinese_name= new byte[64];
                byte[] expire_start_day= new byte[36];
                byte[] expire_end_day= new byte[36];
                byte[] birth_day= new byte[36];
                byte[] version_number= new byte[12];
                byte[] department_code= new byte[20];
                byte[] type_sign= new byte[8];
                byte[] reserved= new byte[16];
                byte[] info_buffer= new byte[64];


                editAddString("dc_ParseTextInfoForForeigner ... ");
                result = dc_ParseTextInfoForForeigner(icdev, 0, text_len, text, english_name, sex, id_number, citizenship, chinese_name, expire_start_day, expire_end_day, birth_day, version_number, department_code, type_sign, reserved);
                if (result != 0)
                {
                    editAddString("dc_ParseTextInfoForForeigner error!");
                    goto safeExit;
                }
                editAddString("dc_ParseTextInfoForForeigner ok!");
               
                tempbuffer = string.Format("name: {0}", System.Text.Encoding.Default.GetString(english_name));

                editAddString(tempbuffer);
                dc_ParseOtherInfo(icdev, 0, sex, info_buffer);


                tempbuffer = string.Format( "sex：{0}/{1}", info_buffer, (string.Compare(System.Text.Encoding.Default.GetString(sex), "1",false) == 0) ? "M" : "F");
                editAddString(tempbuffer);

                tempbuffer = string.Format( "id_number: {0}", System.Text.Encoding.Default.GetString(id_number));
                editAddString(tempbuffer);
                dc_ParseOtherInfo(icdev, 2, citizenship, info_buffer);
                tempbuffer = string.Format("citizenship: {0}/{1}", System.Text.Encoding.Default.GetString(info_buffer), System.Text.Encoding.Default.GetString(citizenship));
                editAddString(tempbuffer);
                tempbuffer = string.Format("chinese_name: {0}", System.Text.Encoding.Default.GetString(chinese_name));
                editAddString(tempbuffer);
                tempbuffer = string.Format( "expire_start_day: {0}", System.Text.Encoding.Default.GetString(expire_start_day));
                editAddString(tempbuffer);
                tempbuffer = string.Format( "expire_end_day: {0}", System.Text.Encoding.Default.GetString(expire_end_day));
                editAddString(tempbuffer);
                tempbuffer = string.Format( "birth_day: {0}", System.Text.Encoding.Default.GetString(birth_day));
                editAddString(tempbuffer);
                tempbuffer = string.Format( "version_number: {0}", System.Text.Encoding.Default.GetString(version_number));
                editAddString(tempbuffer);
                tempbuffer = string.Format( "department_code: {0}", System.Text.Encoding.Default.GetString(department_code));
                editAddString(tempbuffer);
                tempbuffer = string.Format( "type_sign: {0}", System.Text.Encoding.Default.GetString(type_sign));
                editAddString(tempbuffer);
            }*/
            byte[] name = new byte[64];
            byte[] sex = new byte[8];
            byte[] nation = new byte[12];
            byte[] birth_day = new byte[36];
            byte[] address = new byte[144];
            byte[] id_number = new byte[76];
            byte[] department = new byte[64];
            byte[] expire_start_day = new byte[36];
            byte[] expire_end_day = new byte[36];
            byte[] reserved = new byte[76];
            byte[] info_buffer = new byte[64];
            result = dc_find_i_d(icdev);
            if (result != 0)
            {
                editAddString("dc_find_i_d error!");
                goto safeExit;
            }
            int m_hId = dc_start_i_d(icdev);
            if (m_hId < 0)
            {
                editAddString("dc_start_i_d error!");
                goto safeExit;
            }
            editAddString("dc_ParseTextInfo ... ");
            /*result = dc_ParseTextInfo(icdev, 0, text_len, text, name, sex, nation, birth_day, address, id_number, department, expire_start_day, expire_end_day, reserved);
            if (result != 0)
            {
                editAddString("dc_ParseTextInfo error!");
                goto safeExit;
            }
            editAddString("dc_ParseTextInfo ok!");*/
            /*name = */
            Marshal.Copy((IntPtr)dc_i_d_query_name(m_hId), name, 0, name.Length);






            tempbuffer = string.Format("name: {0}", System.Text.Encoding.Default.GetString(name));
            editAddString(tempbuffer);
            //dc_ParseOtherInfo(icdev, 0, sex, info_buffer);
            //info_buffer = dc_i_d_query_sex(m_hId);
            Marshal.Copy((IntPtr)dc_i_d_query_sex(m_hId), info_buffer, 0, info_buffer.Length);
            tempbuffer = string.Format("sex: {0}", System.Text.Encoding.Default.GetString(info_buffer));
            editAddString(tempbuffer);
            // info_buffer = dc_i_d_query_nation(m_hId);
            Marshal.Copy((IntPtr)dc_i_d_query_nation(m_hId), info_buffer, 0, info_buffer.Length);
            tempbuffer = string.Format("nation: {0}", System.Text.Encoding.Default.GetString(info_buffer));
            editAddString(tempbuffer);

            // birth_day = dc_i_d_query_birth(m_hId);
            Marshal.Copy((IntPtr)dc_i_d_query_birth(m_hId), birth_day, 0, birth_day.Length);
            tempbuffer = string.Format("birth_day: {0}", System.Text.Encoding.Default.GetString(birth_day));
            editAddString(tempbuffer);

            //address = dc_i_d_query_address(m_hId);
            Marshal.Copy((IntPtr)dc_i_d_query_address(m_hId), address, 0, address.Length);
            tempbuffer = string.Format("address: {0}", System.Text.Encoding.Default.GetString(address));
            editAddString(tempbuffer);

            //id_number = dc_i_d_query_id_number(m_hId);
            Marshal.Copy((IntPtr)dc_i_d_query_id_number(m_hId), id_number, 0, id_number.Length);
            tempbuffer = string.Format("id_number: {0}", System.Text.Encoding.Default.GetString(id_number));
            editAddString(tempbuffer);

            //department = dc_i_d_query_department(m_hId);
            Marshal.Copy((IntPtr)dc_i_d_query_department(m_hId), department, 0, department.Length);
            tempbuffer = string.Format("department: {0}", System.Text.Encoding.Default.GetString(department));
            editAddString(tempbuffer);

            //expire_start_day = dc_i_d_query_expire_day(m_hId);
            Marshal.Copy((IntPtr)dc_i_d_query_expire_day(m_hId), expire_start_day, 0, expire_start_day.Length);
            tempbuffer = string.Format("expire_start_day: {0}", System.Text.Encoding.Default.GetString(expire_start_day));
            editAddString(tempbuffer);

            //tempbuffer = string.Format("expire_end_day: {0}", System.Text.Encoding.Default.GetString(expire_end_day));
            //editAddString(tempbuffer);
            editAddString("dc_ParsePhotoInfo ...");
            //int rlen1 = 65536;
            //result = dc_i_d_query_photo_bmp_buffer(m_hId, photo, ref photo_len);
            //result = dc_ParsePhotoInfo(m_hId, 0, photo_len, photo, ref rlen1, System.Text.Encoding.Default.GetBytes("me.bmp"));
            result = dc_i_d_query_photo_file(m_hId, System.Text.Encoding.Default.GetBytes("me.bmp"));
            if (result != 0)
            {
                editAddString("dc_ParsePhotoInfo error!");
                goto safeExit;
            }
            editAddString("dc_ParsePhotoInfo ok!");
            System.Drawing.Image img = System.Drawing.Image.FromFile("me.bmp");//双引号里是图片的路径
            pictureBox1.Image = img;
 safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
        }

        private void button14_Click_1(object sender, EventArgs e)
        {
            int icdev = -1;
            int st = -1;
            byte[] _Snr = new byte[100];
            byte[] szSnr = new byte[100];
            short iport = 0;
            string selectPort = comboBox1.Text;
            string selectBaund = comboBox2.Text;
            string subPort = selectPort.Substring(0, 3);
            if (subPort == "com")
            {
                string stringport = selectPort.Substring(3);
                iport = (short)Convert.ToInt32(stringport);
                --iport;
            }
            if (selectPort == "usb")
                iport = 100;
            else if (selectPort == "PCSC")
                iport = 200;

            icdev = dc_init(iport, Convert.ToInt32(selectBaund));
            if ((int)icdev <= 0)
            {
                editAddString("Init Com Error!");
                return;
            }
            else
            {
                editAddString("Init Com ok!");
            }
            short result = -1;
            byte[] buffer = new byte[8192];
            result = dc_Scan2DBarcodeStart(icdev, 0x00);
            if (result != 0)
            {
                editAddString("dc_Scan2DBarcodeStart Error!");
                return;
            }
            int len = 0;
            while (true)
            {
                timeBeginPeriod(1);
                uint start = timeGetTime();
                Thread.Sleep(10);
                result = dc_Scan2DBarcodeGetData(icdev, ref len, buffer);
                if (result == 0)
                {
                    break;
                }
                timeEndPeriod(1);
                uint endtime = timeGetTime();
                if (endtime - start >=30000 )
                {
                    result = -2;
                }
                
                
            }
            dc_Scan2DBarcodeExit(icdev);

            if (result == 0)
            {
                string tempbuffer = string.Format("ercode:{0}", System.Text.Encoding.Default.GetString(buffer));
                editAddString(tempbuffer);
            }
            else if (result == -2)
            {
                //MessageBox("超时", "错误提示", MB_OK);
                editAddString("time Error!");
                goto safeExit;
            }
            safeExit:
            if ((int)icdev > 0)
            {
                st = dc_exit(icdev);
                if (st != 0)
                {
                    editAddString("dc_exit Error!");
                    return;
                }
                else
                {
                    editAddString("dc_exit OK!");
                    icdev = -1;
                }
            }
        }
    }
}
